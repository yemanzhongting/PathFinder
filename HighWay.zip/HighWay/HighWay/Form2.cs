﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RoadNetwork;
using Common;
using DataBase;
using EdgeMatch;
namespace HighWay
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void toolVEtable_Click(object sender, EventArgs e)
        {
            Writer.WriteRoadNetwork("roadnetwork.txt");
        }

        private void toolVertex_Click(object sender, EventArgs e)
        {
            string file = Configure.Root + "/DataClean/roadnetwork-V1.txt";
            var data = Reader.ReadTRoadNetwork(file);
            var veb = new VertexBuilder(data);
            var ptSet = veb.FindKeyPoints();
            string outfile = Configure.Root + "/DataClean/KeyPoint.txt";
            Writer.WriteKeyPoint(ptSet, outfile);
        }

        private void toolEdge_Click(object sender, EventArgs e)
        {
            string file1 = Configure.Root + "/DataClean/roadnetwork-V1.txt";
            var roadData = Reader.ReadTRoadNetwork(file1);
            string file2 = Configure.Root + "/DataClean/关键点.txt";
            var pointData = Reader.ReadKeyPoint(file2);

            var eb = new EdgeBuilder(roadData, pointData);
            var res = eb.FindEdges();

            string outfile = Configure.Root + "/DataClean/边.txt";
            Writer.WriteEdge(res, outfile);
        }

        private void toolCellBase_Click(object sender, EventArgs e)
        {
            var reader = new CellBaseReader();
            reader.ReadAll();
            string outfile1 = Configure.Root + "/DataClean/缓冲区.txt";
            string outfile2 = Configure.Root + "/DataClean/移动基站.txt";
            string outfile3 = Configure.Root + "/DataClean/收费站列表.txt";
            string outfile4 = Configure.Root + "/DataClean/基站分区.txt";
            DataWriter.WriteAllTollStation(reader.TollData, outfile1);
            DataWriter.WriteCellBase(reader.CellData, outfile2);
            DbWriter.WriteStations(reader.TollList, outfile3);

            var gridset = PrepareGridSet.CreateRegionSet(reader.TollData);
            DbWriter.WriteGrid(gridset, outfile4);

        }

        private void toolKeyPoint_Click(object sender, EventArgs e)
        {
            string file1 = Configure.Root + "/DataClean/关键点.txt";
            string file2 = Configure.Root + "/DataClean/收费站.txt";
            var keyPt = Reader.ReadKeyPoint(file1);
            var tollPt = DataReader.ReadKeypointData(file2);
            var pt = new TollStationSet();

            foreach (var d in keyPt.Data)
            {
                int i = tollPt.IndexOf(d.Code);
                if (i == -1)
                {
                    Logger.WriteError(d.ToString());
                }
                else
                {
                    pt.Add(tollPt[i]);
                }

            }

            string file3 = Configure.Root + "/DataClean/顶点列表.txt";
            DbWriter.WriteStations(pt, file3);
        }

        private void toolRoadNetwork_Click(object sender, EventArgs e)
        {
            string file1 = Configure.Root + "/DataClean/roadnetwork-V1.txt";
            var roadData = Reader.ReadTRoadNetwork(file1);
            string outfile = Configure.Root + "/DataClean/roadnetwork-V2.txt";
            Writer.WriteEdge2(roadData, outfile);

            file1 = Configure.Root + "/DataClean/边.txt";
            roadData = Reader.ReadTRoadNetwork(file1);
            outfile = Configure.Root + "/DataClean/边-V2.txt";
            Writer.WriteEdge2(roadData, outfile);
        }
    }
}
