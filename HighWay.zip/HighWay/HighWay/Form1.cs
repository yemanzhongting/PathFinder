﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataBase;
using Common;
using EdgeMatch;
namespace HighWay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolReadBasicData_Click(object sender, EventArgs e)
        {
            var reader = new BasicDataReader();
            var dir = @"D:\Data\Highway\CellBase";
            var file = @"D:\Data\Highway\CellBase\list.txt";
            var filelist = reader.ReadFileList(dir, file);
            foreach (var f in filelist)
            {
                reader.Read(f);
                Logger.WriteLog(file + ":" + DateTime.Now.ToString());
                DbWriter.WriteRoad(reader.RoadSegments, "road.txt");
                DbWriter.WriteStations(reader.FeeStations, "FeePoint.txt");
            }
        }

        private void toolReadRoadSet_Click(object sender, EventArgs e)
        {
            var file = "road-V2.txt";
            var data = RoadRegion.ReadEdgeSetDetail(file);
            DbWriter.WriteRoad(data, "road-V3.txt");
        }

        private void toolRegionSet_Click(object sender, EventArgs e)
        {
            var file = "road-V3.txt";
            var data = RoadRegion.ReadEdgeSetDetail(file);
            var regionSet = RoadRegion.CreateRegionSet(data);
            DbWriter.WriteRegion(regionSet, "region.txt");
        }

        private void toolRoadMatch_Click(object sender, EventArgs e)
        {
            var file = "road-V3.txt";
            var data = RoadRegion.ReadEdgeSetDetail(file);
            var regionSet = RoadRegion.CreateRegionSet(data);
            var cardList = DataReader.ReadCardData(@"D:\Data\Highway\03.交易数据_10000.csv");
            DataWriter.WriteAllEdge(regionSet, cardList, "RoadMatch.txt");


        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void toolVertexSearch_Click(object sender, EventArgs e)
        {
            var vertexFile = $"{Configure.Root}/Database/FeePoint-V2.txt";
            var cardFile = $"{Configure.Root}/03.交易数据_10000.csv";
            var roadFile = $"{Configure.Root}/Database/road-V3.txt";

            var data = RoadRegion.ReadEdgeSetDetail(roadFile);
            var regionLib = RoadRegion.CreateRegionSet(data);
            var cardList = DataReader.ReadCardData(cardFile);
            var feeStationLib = DataReader.ReadKeypointData(vertexFile);
            RoadSet roadSet = new RoadSet();
            DataWriter.WriteAllVertex(regionLib, feeStationLib, roadSet, cardList, "FeestationSearch.txt");

        }

        private void toolToolStation_Click(object sender, EventArgs e)
        {
            var roadFile = $"{Configure.Root}/Database/road-V3.txt";
            var data = RoadRegion.ReadEdgeSetDetail(roadFile);
            var toll = PrepareTollStationSet.CreateTollStationSet(data);
            DataWriter.WriteAllTollStation(toll, "TollStation.txt");
        }

        private void toolGridSet_Click(object sender, EventArgs e)
        {
            //var tollFile = $"{Configure.Root}/Database/TollStation.txt";
            //var data = DataReader.ReadTollData(tollFile);
            //var grids = PrepareGridSet.CreateRegionSet(data);
            //DataWriter.WriteAllGrid(grids,"GridSet.txt");

            var gridFile = $"{Configure.Root}/Database/GridSet.txt";
            var data = DataReader.ReadGridData(gridFile);
            DataWriter.WriteAllGrid(data, "Grid.txt");
        }

        private void toolRoadSearch_Click(object sender, EventArgs e)
        {
            var vertexFile = $"{Configure.Root}/Database/FeePoint-V2.txt";
            var tollFile = $"{Configure.Root}/Database/TollStation.txt";
            var gridFile = $"{Configure.Root}/Database/GridSet.txt";
            var roadFile = $"{Configure.Root}/Database/RoadNetwork.txt";

            var cardFile = $"{Configure.Root}/03.交易数据_10000.csv";


            var cardList = DataReader.ReadCardData(cardFile);
            var feeStationLib = DataReader.ReadKeypointData(vertexFile);
            var tollSet = DataReader.ReadTollData(tollFile);
            var gridData = DataReader.ReadGridData(gridFile);
            RoadSet roadSet = DataReader.ReadRoadData(roadFile);
            var ts = new TollSearch(feeStationLib, roadSet, gridData, tollSet);

            var writer = new StreamWriter("TollSearch.txt");
            foreach (var card in cardList)
            {
                var road = ts.RoadSearch(card);
                writer.WriteLine(road.ToString());
            }
            writer.Close();


        }

        private void toolTollBuffer_Click(object sender, EventArgs e)
        {
            var tollFile = $"{Configure.Root}/Database/TollStation.txt";
            var tollSet = DataReader.ReadTollData(tollFile);

            DataWriter.WriteAllTollStation(tollSet,"TollBuffer.txt");
        }

        private void toolRoad_Click(object sender, EventArgs e)
        {
            var roadFile = $"{Configure.Root}/Database/RoadNetwork.txt";
            RoadSet roadSet = DataReader.ReadRoadData(roadFile);
            DataWriter.WriteRoadNetWork(roadSet,"RoadSet.txt");
        }
    }
}
