﻿namespace HighWay
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolVEtable = new System.Windows.Forms.ToolStripButton();
            this.toolVertex = new System.Windows.Forms.ToolStripButton();
            this.toolEdge = new System.Windows.Forms.ToolStripButton();
            this.toolCellBase = new System.Windows.Forms.ToolStripButton();
            this.toolKeyPoint = new System.Windows.Forms.ToolStripButton();
            this.toolRoadNetwork = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolVEtable,
            this.toolVertex,
            this.toolEdge,
            this.toolCellBase,
            this.toolKeyPoint,
            this.toolRoadNetwork});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(987, 39);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolVEtable
            // 
            this.toolVEtable.Image = ((System.Drawing.Image)(resources.GetObject("toolVEtable.Image")));
            this.toolVEtable.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolVEtable.Name = "toolVEtable";
            this.toolVEtable.Size = new System.Drawing.Size(103, 36);
            this.toolVEtable.Text = "VE表";
            this.toolVEtable.Click += new System.EventHandler(this.toolVEtable_Click);
            // 
            // toolVertex
            // 
            this.toolVertex.Image = ((System.Drawing.Image)(resources.GetObject("toolVertex.Image")));
            this.toolVertex.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolVertex.Name = "toolVertex";
            this.toolVertex.Size = new System.Drawing.Size(101, 36);
            this.toolVertex.Text = "顶点";
            this.toolVertex.Click += new System.EventHandler(this.toolVertex_Click);
            // 
            // toolEdge
            // 
            this.toolEdge.Image = ((System.Drawing.Image)(resources.GetObject("toolEdge.Image")));
            this.toolEdge.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolEdge.Name = "toolEdge";
            this.toolEdge.Size = new System.Drawing.Size(76, 36);
            this.toolEdge.Text = "边";
            this.toolEdge.Click += new System.EventHandler(this.toolEdge_Click);
            // 
            // toolCellBase
            // 
            this.toolCellBase.Image = ((System.Drawing.Image)(resources.GetObject("toolCellBase.Image")));
            this.toolCellBase.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolCellBase.Name = "toolCellBase";
            this.toolCellBase.Size = new System.Drawing.Size(101, 36);
            this.toolCellBase.Text = "基站";
            this.toolCellBase.Click += new System.EventHandler(this.toolCellBase_Click);
            // 
            // toolKeyPoint
            // 
            this.toolKeyPoint.Image = ((System.Drawing.Image)(resources.GetObject("toolKeyPoint.Image")));
            this.toolKeyPoint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolKeyPoint.Name = "toolKeyPoint";
            this.toolKeyPoint.Size = new System.Drawing.Size(126, 36);
            this.toolKeyPoint.Text = "关键点";
            this.toolKeyPoint.Click += new System.EventHandler(this.toolKeyPoint_Click);
            // 
            // toolRoadNetwork
            // 
            this.toolRoadNetwork.Image = ((System.Drawing.Image)(resources.GetObject("toolRoadNetwork.Image")));
            this.toolRoadNetwork.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolRoadNetwork.Name = "toolRoadNetwork";
            this.toolRoadNetwork.Size = new System.Drawing.Size(101, 36);
            this.toolRoadNetwork.Text = "路网";
            this.toolRoadNetwork.Click += new System.EventHandler(this.toolRoadNetwork_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(987, 839);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolVEtable;
        private System.Windows.Forms.ToolStripButton toolVertex;
        private System.Windows.Forms.ToolStripButton toolEdge;
        private System.Windows.Forms.ToolStripButton toolCellBase;
        private System.Windows.Forms.ToolStripButton toolKeyPoint;
        private System.Windows.Forms.ToolStripButton toolRoadNetwork;
    }
}