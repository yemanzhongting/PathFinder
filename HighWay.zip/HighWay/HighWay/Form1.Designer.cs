﻿namespace HighWay
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolReadBasicData = new System.Windows.Forms.ToolStripButton();
            this.toolReadRoadSet = new System.Windows.Forms.ToolStripButton();
            this.toolRegionSet = new System.Windows.Forms.ToolStripButton();
            this.toolRoadMatch = new System.Windows.Forms.ToolStripButton();
            this.toolVertexSearch = new System.Windows.Forms.ToolStripButton();
            this.toolToolStation = new System.Windows.Forms.ToolStripButton();
            this.toolGridSet = new System.Windows.Forms.ToolStripButton();
            this.toolRoadSearch = new System.Windows.Forms.ToolStripButton();
            this.toolTollBuffer = new System.Windows.Forms.ToolStripButton();
            this.toolRoad = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolReadBasicData,
            this.toolReadRoadSet,
            this.toolRegionSet,
            this.toolRoadMatch,
            this.toolVertexSearch,
            this.toolToolStation,
            this.toolGridSet,
            this.toolRoadSearch,
            this.toolTollBuffer,
            this.toolRoad});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1701, 39);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolReadBasicData
            // 
            this.toolReadBasicData.Image = ((System.Drawing.Image)(resources.GetObject("toolReadBasicData.Image")));
            this.toolReadBasicData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolReadBasicData.Name = "toolReadBasicData";
            this.toolReadBasicData.Size = new System.Drawing.Size(147, 36);
            this.toolReadBasicData.Text = "基础数据";
            this.toolReadBasicData.Click += new System.EventHandler(this.toolReadBasicData_Click);
            // 
            // toolReadRoadSet
            // 
            this.toolReadRoadSet.Image = ((System.Drawing.Image)(resources.GetObject("toolReadRoadSet.Image")));
            this.toolReadRoadSet.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolReadRoadSet.Name = "toolReadRoadSet";
            this.toolReadRoadSet.Size = new System.Drawing.Size(147, 36);
            this.toolReadRoadSet.Text = "道路数据";
            this.toolReadRoadSet.Click += new System.EventHandler(this.toolReadRoadSet_Click);
            // 
            // toolRegionSet
            // 
            this.toolRegionSet.Image = ((System.Drawing.Image)(resources.GetObject("toolRegionSet.Image")));
            this.toolRegionSet.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolRegionSet.Name = "toolRegionSet";
            this.toolRegionSet.Size = new System.Drawing.Size(147, 36);
            this.toolRegionSet.Text = "分区组织";
            this.toolRegionSet.Click += new System.EventHandler(this.toolRegionSet_Click);
            // 
            // toolRoadMatch
            // 
            this.toolRoadMatch.Image = ((System.Drawing.Image)(resources.GetObject("toolRoadMatch.Image")));
            this.toolRoadMatch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolRoadMatch.Name = "toolRoadMatch";
            this.toolRoadMatch.Size = new System.Drawing.Size(147, 36);
            this.toolRoadMatch.Text = "路段匹配";
            this.toolRoadMatch.Click += new System.EventHandler(this.toolRoadMatch_Click);
            // 
            // toolVertexSearch
            // 
            this.toolVertexSearch.Image = ((System.Drawing.Image)(resources.GetObject("toolVertexSearch.Image")));
            this.toolVertexSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolVertexSearch.Name = "toolVertexSearch";
            this.toolVertexSearch.Size = new System.Drawing.Size(147, 36);
            this.toolVertexSearch.Text = "顶点匹配";
            this.toolVertexSearch.Click += new System.EventHandler(this.toolVertexSearch_Click);
            // 
            // toolToolStation
            // 
            this.toolToolStation.Image = ((System.Drawing.Image)(resources.GetObject("toolToolStation.Image")));
            this.toolToolStation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolToolStation.Name = "toolToolStation";
            this.toolToolStation.Size = new System.Drawing.Size(147, 36);
            this.toolToolStation.Text = "站点列表";
            this.toolToolStation.Click += new System.EventHandler(this.toolToolStation_Click);
            // 
            // toolGridSet
            // 
            this.toolGridSet.Image = ((System.Drawing.Image)(resources.GetObject("toolGridSet.Image")));
            this.toolGridSet.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolGridSet.Name = "toolGridSet";
            this.toolGridSet.Size = new System.Drawing.Size(147, 36);
            this.toolGridSet.Text = "格网准备";
            this.toolGridSet.Click += new System.EventHandler(this.toolGridSet_Click);
            // 
            // toolRoadSearch
            // 
            this.toolRoadSearch.Image = ((System.Drawing.Image)(resources.GetObject("toolRoadSearch.Image")));
            this.toolRoadSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolRoadSearch.Name = "toolRoadSearch";
            this.toolRoadSearch.Size = new System.Drawing.Size(147, 36);
            this.toolRoadSearch.Text = "道路搜索";
            this.toolRoadSearch.Click += new System.EventHandler(this.toolRoadSearch_Click);
            // 
            // toolTollBuffer
            // 
            this.toolTollBuffer.Image = ((System.Drawing.Image)(resources.GetObject("toolTollBuffer.Image")));
            this.toolTollBuffer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolTollBuffer.Name = "toolTollBuffer";
            this.toolTollBuffer.Size = new System.Drawing.Size(122, 36);
            this.toolTollBuffer.Text = "缓冲区";
            this.toolTollBuffer.Click += new System.EventHandler(this.toolTollBuffer_Click);
            // 
            // toolRoad
            // 
            this.toolRoad.Image = ((System.Drawing.Image)(resources.GetObject("toolRoad.Image")));
            this.toolRoad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolRoad.Name = "toolRoad";
            this.toolRoad.Size = new System.Drawing.Size(97, 36);
            this.toolRoad.Text = "路网";
            this.toolRoad.Click += new System.EventHandler(this.toolRoad_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1701, 861);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolReadBasicData;
        private System.Windows.Forms.ToolStripButton toolReadRoadSet;
        private System.Windows.Forms.ToolStripButton toolRegionSet;
        private System.Windows.Forms.ToolStripButton toolRoadMatch;
        private System.Windows.Forms.ToolStripButton toolVertexSearch;
        private System.Windows.Forms.ToolStripButton toolToolStation;
        private System.Windows.Forms.ToolStripButton toolGridSet;
        private System.Windows.Forms.ToolStripButton toolRoadSearch;
        private System.Windows.Forms.ToolStripButton toolTollBuffer;
        private System.Windows.Forms.ToolStripButton toolRoad;
    }
}

