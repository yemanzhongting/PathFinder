﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Common;
using DataBase;
namespace EdgeMatch
{
    /// <summary>
    /// 1.读取卡片数据
    /// 2.读取收费站列表数据
    /// 3.读取道路邻接表的数据
    /// </summary>
    public class DataReader
    {
        /// <summary>
        /// 读取分区文件
        /// </summary>
        /// <param name="file">分区文件名称</param>
        /// <returns>分区数据集合</returns>
        public static GridSet ReadGridData(string file)
        {
            var res=new GridSet();
            try
            {
                var reader=new StreamReader(file);
                var grid =new Grid();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();

                    if (line != null && line.Contains("#"))
                    {
                        line = line.Replace("#", "");
                        grid.Id = line;
                    }
                    else if (line != null && line.Contains("END"))
                    {
                        res.Data.Add(grid);
                        grid = new Grid();
                    }
                    else
                    {
                        if (line != null)
                        {
                            var v = new TollStation();
                            v.Parse(line);
                            grid.AddVertex(v);
                        }
                    }
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

            return res;
        }

        /// <summary>
        /// 读取收费站数据
        /// 该数据是计算道路还原的基础数据
        /// </summary>
        /// <param name="file">收费站列表数据文件（包含移动基站信息）</param>
        /// <returns></returns>
        public static TollBufferSet ReadTollData(string file)
        {
            var res=new TollBufferSet();
            try
            {
                var reader=new StreamReader(file);
                var toll=new TollBuffer();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();

                    if (line != null && line.Contains("#"))
                    {
                        line = line.Replace("#", "");
                        var v=new TollStation();
                        v.Parse(line);
                        toll.Id = v;
                    }
                    else if (line != null && line.Contains("END"))
                    {
                        res.Add(toll);
                        toll=new TollBuffer();
                    }
                    else
                    {
                        if (line != null)
                        {
                            var cellbase=new CellBase();
                            cellbase.Parse(line);
                            toll.Add(cellbase);
                        }
                        
                    }
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
            return res;
        }

        /// <summary>
        /// 读取卡片数据
        /// </summary>
        /// <param name="file">卡片数据文件路径</param>
        /// <returns>数据集合</returns>
        public static List<Card> ReadCardData(string file)
        {
            var res = new List<Card>();
            try
            {
                var reader = new StreamReader(file);
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (!string.IsNullOrEmpty(line) && !line.Contains("#"))
                    {
                        var card = new Card();
                        card.Parse(line);
                        res.Add(card);
                    }
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
            return res;
        }
        /// <summary>
        /// 读取收费站列表数据
        /// #ID,lon,lat,height,weight
        ///08601小军山,114.13476,30.39420,10.89,791
        ///00513军山,114.10338,30.39757,16.93,48
        ///00510武汉西,114.04929,30.47383,15.61,174
        ///00509蔡甸,114.04674,30.57062,20.05,313
        ///00508武汉北,113.90512,30.82043,26.45,234
        /// </summary>
        /// <param name="filename">文件路径</param>
        /// <returns></returns>
        public static TollStationSet ReadKeypointData(string filename)
        {
            var res = new TollStationSet();
            try
            {
                var reader = new StreamReader(filename);
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line != null && !line.Contains("#"))
                    {
                        TollStation v=new TollStation();
                        v.Parse(line);
                        res.Add(v);
                    }
                }
                reader.Close();

            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
            return res;
        }

        /// <summary>
        /// 读取路网数据
        /// </summary>
        /// <param name="filename">路网数据名称</param>
        /// <returns></returns>
        public static RoadSet ReadRoadData(string filename)
        {
            var res = new RoadSet();
            try
            {
                var reader = new StreamReader(filename);
                var road = new Road();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line != null && line.Contains("#"))
                    {
                        road.Id = line.Replace("#", "");
                    }
                    else if (line != null && line.Contains("END"))
                    {
                        
                        res.Add(road);
                        road = new Road();
                    }
                    else
                    {
                        road.Parse(line);
                    }
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
            return res;
        }
    }
}
