﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.IO;
namespace EdgeMatch
{
    /// <summary>
    /// 对道路搜索结果进行保存
    /// </summary>
    public class DataWriter
    {
        /// <summary>
        /// 将卡列表中的记录对应的边写出到文件
        /// </summary>
        /// <param name="regionSet">区域列表</param>
        /// <param name="cardList">卡片列表</param>
        /// <param name="file">输出文件</param>
        public static void WriteAllEdge(RegionSet regionSet, List<Card> cardList, string file)
        {
            try
            {
                var writer = new StreamWriter(file);
                EdgeSearch es = new EdgeSearch(regionSet);
                foreach (var card in cardList)
                {
                    var record = es.FindEdge(card);
                    writer.WriteLine(record);
                }
                writer.Close();

            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }
        }
        /// <summary>
        /// 将收费站集合写出到文件
        /// </summary>
        /// <param name="tollData">收费站数据集合</param>
        /// <param name="file">输出文件</param>
        public static void WriteAllTollStation(TollBufferSet tollData, string file)
        {
            try
            {
                var writer = new StreamWriter(file);
               
                foreach (var d in tollData.Data)
                {
                   writer.WriteLine(d.ToString());
                }
                writer.Close();

            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }
        }
        /// <summary>
        /// 将分区数据写出到文件中
        /// </summary>
        /// <param name="gridData">分区数据集合</param>
        /// <param name="file">输出文件名称</param>
        public static void WriteAllGrid(GridSet gridData, string file)
        {
            try
            {
                var writer=new StreamWriter(file);
                foreach (var d in gridData.Data)
                {
                    writer.WriteLine(d.ToString());
                    
                }

                writer.Close();
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
        }
        //写出所有的移动基站数据
        public static void WriteCellBase(CellBaseSet cellData, string file)
        {
            try
            {
                var writer = new StreamWriter(file);
                foreach (var d in cellData.Data)
                {
                    writer.WriteLine(d.ToString());

                }

                writer.Close();
            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }
        }

        /// <summary>
        /// 将卡列表中的记录对应的边写出到文件
        /// </summary>
        /// <param name="regionSet">区域列表</param>
        /// <param name="cardList">卡片列表</param>
        /// <param name="file">输出文件</param>
        public static void WriteAllVertex(RegionSet regionSet, TollStationSet feeStationLib,
            RoadSet roadLib,List<Card> cardList,string file)
        {
            try
            {
                var writer = new StreamWriter(file);

                VertexSearch vs=new VertexSearch(regionSet,feeStationLib,roadLib);

                foreach (var card in cardList)
                {
                    //var record = vs.FindFeeStations(card);
                    //writer.WriteLine(card.HeaderString());
                    var record = vs.RoadSearch(card);
                    writer.WriteLine(record.ToString());
                }
                writer.Close();

            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }
        }

        public static void WriteRoadNetWork(RoadSet roadLib,  string file)
        {
            try
            {
                var writer = new StreamWriter(file);

                foreach (var road in roadLib.Data)
                {
                    writer.WriteLine($"#{road.Id},{road.Azimuth}");
                    for (int i = 0; i < road.Data.Count; i++)
                    {
                        double length = 0;
                        var p = road.Data[i];
                        if (i > 0)
                        {
                            var p0 = road.Data[i - 1];
                            length = CoorTrans.GetLength(p0.Position, p.Position);
                            if (length > 50000)
                                length = 0;
                        }
                        writer.WriteLine($"{p.Name},{length:f2}");
                    }
                    writer.WriteLine("END");
                }
                writer.Close();

            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }
        }
    }
}
