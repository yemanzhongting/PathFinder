﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace EdgeMatch
{
    /// <summary>
    /// 1.根据Card数据，搜索相应的边
    /// 2.并将相关结果打印
    /// </summary>
    public class EdgeSearch
    {
        public RegionSet Data { get; set; }

        public EdgeSearch(RegionSet data)
        {
            Data = data;
        }
        
        /// <summary>
        /// 根据卡片中记录的数据，搜索所有可能经过的边
        /// </summary>
        /// <param name="card">收费中所读取的内容</param>
        /// <returns>边的列表</returns>
        public string FindEdge(Card card)
        {
            string res = card.HeaderString();

            try
            {
                foreach (var cellId in card.CellBaseList)
                {
                   string edgeStr= Data.FindEdgeString(cellId);
                    res += $"\n{edgeStr}";
                }
                res += "\nEnd";
            }
            catch (Exception ex)
            {
               Logger.WriteError(ex.Message);
            }

            return res;
        }
    }
}
