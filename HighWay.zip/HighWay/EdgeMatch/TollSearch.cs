﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace EdgeMatch
{
    /// <summary>
    /// 搜索收费站
    /// </summary>
    public class TollSearch
    {
        /// <summary>
        /// 收费站及其坐标
        /// </summary>
        public TollStationSet FeeStationData { get; set; }
        /// <summary>
        /// 道路邻接表
        /// </summary>
        public RoadSet RoadData { get; set; }
        /// <summary>
        /// 分区表
        /// </summary>
        public GridSet GridData { get; set; }
        /// <summary>
        /// 收费站及其缓冲区的移动基站列表
        /// </summary>
        public TollBufferSet TollSet { get; set; }

        public TollSearch(TollStationSet feeStationData, RoadSet roadSet, GridSet gridData, TollBufferSet tollData)
        {
            FeeStationData = feeStationData;
            RoadData = roadSet;
            GridData = gridData;
            TollSet = tollData;
        }

        /// <summary>
        /// 根据收费卡的内容，搜索相应的顶点
        /// todo: 需要重点完善
        /// </summary>
        /// <param name="card">收费中所读取的内容</param>
        /// <returns></returns>
        public Road RoadSearch(Card card)
        {
            var res = new Road();
            try
            {
                var v = FeeStationData.Find(card.StartCode);
                res.Id = card.HeaderString();
                res.Start = v;
                v = FeeStationData.Find(card.EndCode);
                res.End = v;
                res.Length = CoorTrans.GetLength(res.Start.Position, res.End.Position);
                res.Azimuth = CoorTrans.GetAzimuth(res.Start.Position, res.End.Position);

                //todo 搜索中间路段
                foreach (var cellId in card.CellBaseList)
                {
                    TollStationSet vertexSet = GridData.FindTollSet(cellId);

                    foreach (var item in vertexSet.Data)
                    {
                        int index = TollSet.IndexOf(item);
                        var toll = TollSet.Data[index];
                        if(toll.Contains(cellId))

                        if (!(item.Name == res.Start.Name || item.Name == res.End.Name))
                        {
                            res.Add(item);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

            return res;
        }
    }
}
