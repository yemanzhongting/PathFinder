﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace EdgeMatch
{
    /// <summary>
    /// 1. 根据收费卡的内容，搜索相应的顶点
    /// 2. 搜索过程中补充时空信息的约束
    /// 3. 补全缺失的数据
    /// 4. 质量检核与标定
    /// 5. 信息预警
    /// 7.方位角约束
    /// </summary>
    public class VertexSearch
    {
        /// <summary>
        /// 区域代码-路段-移动基站列表
        /// </summary>
        public RegionSet RegionData { get; set; }
        /// <summary>
        /// 收费站及其坐标
        /// </summary>
        public TollStationSet FeeStationData { get; set; }
        /// <summary>
        /// 道路邻接表
        /// </summary>
        public RoadSet RoadData { get; set; }

        public VertexSearch(RegionSet regionLib, TollStationSet feeStationLib, RoadSet roadLib)
        {
            RegionData = regionLib;
            FeeStationData = feeStationLib;
            RoadData = roadLib;
        }

        /// <summary>
        /// 根据收费卡的内容，搜索相应的顶点
        /// </summary>
        /// <param name="card">收费中所读取的内容</param>
        /// <returns></returns>
        public TollStationSet FindFeeStations(Card card)
        {
            var res = new TollStationSet();
            try
            {
                var v = FeeStationData.Find(card.StartCode);
                res.Add(v);

                //todo 搜索中间路段
                v = FeeStationData.Find(card.EndCode);
                res.Add(v);
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

            return res;
        }

        /// <summary>
        /// 根据收费卡的内容，搜索相应的顶点
        /// todo: 需要重点完善
        /// </summary>
        /// <param name="card">收费中所读取的内容</param>
        /// <returns></returns>
        public Road RoadSearch(Card card)
        {
            var res = new Road();
            try
            {
                var v = FeeStationData.Find(card.StartCode);
                res.Id = card.HeaderString();
                res.Start = v;
                v = FeeStationData.Find(card.EndCode);
                res.End = v;
                res.Length = CoorTrans.GetLength(res.Start.Position, res.End.Position);
                res.Azimuth = CoorTrans.GetAzimuth(res.Start.Position, res.End.Position);

                //todo 搜索中间路段
                foreach (var cellId in card.CellBaseList)
                {
                    var edges = RegionData.FindEdge(cellId);
                    TollStationSet vertexSet = edges.ToVertexSet;

                    //if (vertexSet.Count < 1) //没有查找相应边，返回一个空的顶点
                    //{
                    //    v=new Vertex();
                    //    res.Add(v);
                    //}
                    //else 
                    //{
                    foreach (var item in vertexSet.Data)
                    {
                        if(! (item.Name == res.Start.Name || item.Name == res.End.Name))
                        {
                            res.Add(item);
                        }
                    }
                    //}

                }
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

            return res;
        }
    }
}
