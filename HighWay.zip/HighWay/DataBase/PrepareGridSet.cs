﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace DataBase
{
    /// <summary>
    /// 准备区域数据集
    /// 利用顶点数据，准备分区数据集合
    /// 目的是为了后续使用过程中加快搜索速度
    /// </summary>
    public class PrepareGridSet
    {
        public static GridSet CreateRegionSet(TollBufferSet tollSet)
        {
            var rs = new GridSet();
            try
            {
                foreach (var toll in tollSet.Data)
                {
                    TollStation v = toll.Id;
                    foreach (var cb in toll.CellbaseData.Data)
                    {
                        rs.AddGrid(cb.Lac,v);
                    }
                }

            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }

            return rs;
        }
    }
}
