﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace DataBase
{
    /// <summary>
    /// 读取移动基站数据，形成TollBuffer
    /// 1. 根据收费站连续两次标记，记录收费站的Id、名称、坐标、
    /// </summary>
    public class CellBaseReader
    {
        public CellBaseSet CellData;
        public TollBufferSet TollData;
        public TollStationSet TollList;

        public CellBaseReader()
        {
            CellData = new CellBaseSet();
            TollData = new TollBufferSet();
            TollList = new TollStationSet();
        }
        public void ReadAll()
        {
            string dir = Configure.Root + "/DataClean/201805";
            var fileList = ReadFileList(dir, "list.txt");
            foreach (var f in fileList)
            {
                CheckFile(f);
                Read(f);
            }
        }

        private void CheckFile(string f)
        {
            int i = 0;
            var reader = new StreamReader(f);
            Logger.WriteLog(f);
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                if (line.Length < 40)
                {
                    string text = $"   Line{i}:{line}";
                    Logger.WriteLog(text);
                }
                i++;
            }
            reader.Close();
        }

        /// <summary>
        /// 读取移动基站内容
        // 08501,琴台
        ///0,0,2018-04-13 14:17:11,46000,FULL,24,255,{46000,28732,3204,24,-65,4}{{EDGE,28732,32332,23},{EDGE,28732,47392,19},{EDGE,28732,47393,18},{EDGE,28732,3256,18},{EDGE,28732,32331,18},{EDGE,0,65535,18},{EDGE,28732,32333,28}},{11,114.15800044,30.57901455,16.299999237060547,79.2,2018-04-13 14:17:09}
        ///1,0,2018-04-13 14:17:17,46000,FULL,24,1,{46000,28732,3204,24,-65,4}{{EDGE,28732,32332,27},{EDGE,28937,22848,21},{EDGE,28937,22847,21},{EDGE,28732,32331,20},{EDGE,0,65535,23},{EDGE,28732,32333,28}},{15,114.15670178,30.57902163,16.0,72.0,2018-04-13 14:17:15}
        ///08501,琴台
        ///30,0,2018-04-13 14:20:14,46000,FULL,30,255,{46000,28937,12777,30,-53,4}{{EDGE,28732,22837,18},{EDGE,28732,32332,21},{EDGE,28937,12778,21},{EDGE,28732,43053,18},{EDGE,28937,12779,25},{EDGE,28732,43052,19},{EDGE,28937,22849,24}},{7,114.13471115,30.5748832,15.699999809265137,0.0,2018-04-13 14:20:12}
        ///31,0,2018-04-13 14:20:20,46000,FULL,30,255,{46000,28937,12777,30,-53,4}{{EDGE,28732,32332,20},{EDGE,28937,12778,22},{EDGE,28732,43053,18},{EDGE,28937,12779,24},{EDGE,28732,43052,19},{EDGE,28937,22849,25}},{14,114.13471291,30.57488257,15.899999618530273,0.0,2018-04-13 14:20:18}
        ///90113,新天铺枢纽
        ///51,0,2018-04-13 14:22:21,46000,FULL,23,2,{46000,28937,60577,23,-67,4}{{EDGE,28722,36662,15},{EDGE,28722,43392,21},{EDGE,0,65535,15},{EDGE,28722,43391,15}},{17,114.12628331,30.5705315,10.300000190734863,59.399998,2018-04-13 14:22:19}
        ///52,0,2018-04-13 14:22:27,46000,FULL,23,1,{46000,28937,60579,23,-67,4}{{EDGE,28722,36662,15},{EDGE,28722,43392,24},{EDGE,0,65535,15}},{9,114.12544689,30.57009935,10.300000190734863,54.0,2018-04-13 14:22:25}
        ///90113,新天铺枢纽
        ///89,0,2018-04-13 14:26:11,46000,FULL,31,255,{46000,29189,35344,31,-51,4}{{EDGE,29194,54517,25},{EDGE,28722,6653,21},{EDGE,0,65535,23},{EDGE,29189,36062,22},{EDGE,29189,35344,25},{EDGE,29194,33386,24}},{13,114.10703093,30.60830598,35.29999923706055,51.3,2018-04-13 14:26:09}
        ///90,0,2018-04-13 14:26:17,46000,FULL,31,0,{46000,29189,35344,31,-51,4}{{EDGE,29194,54517,24},{EDGE,0,65535,22},{EDGE,29189,36062,22},{EDGE,29194,41192,27}},{10,114.10700593,30.60899521,35.599998474121094,44.1,2018-04-13 14:26:15}
        // 20301,长青
        ///91,0,2018-04-13 14:26:23,46000,FULL,31,2,{46000,29189,35344,31,-51,4}{{EDGE,29194,54517,24},{EDGE,29194,33895,26},{EDGE,0,65535,23},{EDGE,29189,36062,23},{EDGE,29194,41192,26}},{9,114.10710934,30.60962486,34.5,42.3,2018-04-13 14:26:21}
        ///92,0,2018-04-13 14:26:29,46000,FULL,31,0,{46000,29189,35344,31,-51,4}{{EDGE,29194,54517,23},{EDGE,29189,38666,24},{EDGE,0,65535,23},{EDGE,29194,33895,25},{EDGE,29194,33894,25},{EDGE,29189,36062,23},{EDGE,29194,41192,25}},{12,114.10745222,30.61011355,31.899999618530273,36.899998,2018-04-13 14:26:27}
        /// </summary>
        /// <param name="filepath"></param>
        private void Read(string filepath)
        {
            try
            {
                var reader = new StreamReader(filepath);
                var roadBuffer = new RoadBuffer();
                var tollBuffer = new TollBuffer();
                var cellBase = new CellBaseSet();
                int step = 0; //记号
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line == null || line.Length < 5)
                    {
                        continue;
                    }
                    //20301,长青区
                    if (line.Length < 50)
                    {

                        var toll = ParseKeyPoint(line);
                        if (step % 2 == 0)
                        {
                            //收费站缓冲区开始
                            tollBuffer = new TollBuffer();
                            tollBuffer.Id = toll;
                            if (step > 1)
                            {
                                toll.Position = cellBase[cellBase.Count - 1].Position;
                                //路段缓冲区结束
                                roadBuffer.EndPoint = toll;
                                roadBuffer.CellBaseList = cellBase;

                                //将移动基站向两个收费站分配
                                TollBufferSet tbs = new TollBufferSet();
                                PushTollStation(ref tbs, roadBuffer);
                                //更新属性
                                foreach (var d in tbs.Data)
                                {
                                    TollData.Add(d);
                                }
                                CellData.Add(cellBase);

                            }

                        }
                        else
                        {
                            //移动基站分配到该收费站缓冲区
                            tollBuffer.CellbaseData = cellBase;

                            //todo:计算收费站的坐标 
                            var pos = new Coordinate();
                            TollPosition(ref pos, cellBase);
                            toll.Position = pos;
                            tollBuffer.Id = toll;

                            //更新属性
                            CellData.Add(cellBase);
                            TollData.Add(tollBuffer);
                            TollList.Add(toll);


                            //路段缓冲区开始
                            roadBuffer = new RoadBuffer();
                            roadBuffer.StartPoint = toll;

                        }
                        //重置移动基站列表数据集合
                        cellBase = new CellBaseSet();
                        step++;
                    }
                    //"0,0,2015-03-28 11:05:00,46001,FULL,22,255,{46001,7121,35521,22,-69,4}{{EDGE,7121,54842,11},{EDGE,7121,55303,14},{EDGE,7121,30101,10},{EDGE,7121,48381,21},{EDGE,7121,35522,10},{EDGE,0,65535,11},{EDGE,7121,59772,9}},{10,114.06388207,30.45467572,19.600000381469727,46.8,2015-03-28 11:04:52}"
                    else if (line.Contains("{46001,") || line.Contains("{46000,"))
                    {
                        ParseCellBase(line, ref cellBase);
                    }
                }
                reader.Close();

            }
            catch (Exception ex)
            {
                string text = $"CellBaseReader.01: {ex.Message}--{filepath}";
                Logger.WriteError(text);
            }
        }

        private void TollPosition(ref Coordinate pos, CellBaseSet cellBase)
        {
            List<double> lon = new List<double>();
            List<double> lat = new List<double>();
            List<double> ht = new List<double>();
            foreach (var d in cellBase.Data)
            {
                lon.Add(d.Position.Lon);
                lat.Add(d.Position.Lat);
                ht.Add(d.Position.Height);
            }

            pos.Lon = Utility.Median(lon);
            pos.Lat = Utility.Median(lat);
            pos.Height = Utility.Median(ht);
            pos.Weight = cellBase.Count;
        }

        /// <summary>
        /// 将边内的移动基站根据距离划分到顶点（起点和终点的收费站）内；
        /// 划分依据：
        ///   （1）移动基站覆盖的经验距离(L_EXP)
        ///        如果起点和终点的距离(L_BE)<L_EXP;将其中所有基站重复归属到两个端点
        ///   （2）如果L_BE>L_EXP，总距离的0.6范围内归属自己
        /// </summary>
        /// <param name="res">顶点（收费站）集合</param>
        /// <param name="edge">路段</param>
        private static void PushTollStation(ref TollBufferSet res, RoadBuffer edge)
        {
            //如果起点站是高权点
            if (Rejector.HighWeightTollStation(edge.StartPoint.Code))
            {
                PushTollStation(ref res, edge, edge.StartPoint);
            }
            //如果终点站是高权点
            else if (Rejector.HighWeightTollStation(edge.EndPoint.Code))
            {
                PushTollStation(ref res, edge, edge.EndPoint);
            }

            //两个收费站点之间的距离很短，小于一个移动站覆盖范围
            else if (edge.Length < Configure.MaxCoverDistance)
            {

                //如果不是0权点
                if (!(Rejector.ZeroWeightTollStation(edge.StartPoint.Code) ||
                       Rejector.ZeroWeightTollStation(edge.EndPoint.Code)))
                {
                    PushTollStation(ref res, edge, edge.StartPoint);
                    PushTollStation(ref res, edge, edge.EndPoint);
                }
            }
            //两个基站之间的距离较长
            else
            {
                double limit = edge.Length * 0.6;
                //
                if (edge.StartPoint.Valid()&&(!Rejector.ZeroWeightTollStation(edge.StartPoint.Code)))
                {
                    var start = new TollBuffer { Id = edge.StartPoint };

                    foreach (var d in edge.CellBaseList.Data)
                    {
                        if (d.Valid())
                        {
                            double length = CoorTrans.GetLength(start.Id.Position, d.Position);
                            if (length < limit)
                                start.Add(d);
                        }
                    }
                    res.Add(start);
                }
                if (edge.EndPoint.Valid()&&(!Rejector.ZeroWeightTollStation(edge.EndPoint.Code)))
                {
                    var end = new TollBuffer { Id = edge.EndPoint };
                    foreach (var d in edge.CellBaseList.Data)
                    {
                        if (d.Valid())
                        {
                            double length = CoorTrans.GetLength(end.Id.Position, d.Position);
                            if (length < limit)
                                end.Add(d);

                        }
                    }
                    res.Add(end);
                }

            }
        }

        /// <summary>
        /// 将边中移动基站压入到顶点toll的缓冲区中
        /// </summary>
        /// <param name="res"></param>
        /// <param name="edge"></param>
        /// <param name="toll"></param>
        private static void PushTollStation(ref TollBufferSet res, RoadBuffer edge, TollStation toll)
        {

            if (toll.Valid())
            {
                var tollBuffer = new TollBuffer { Id = toll };
                foreach (var d in edge.CellBaseList.Data)
                {
                    if (d.Valid())
                    {
                        tollBuffer.Add(d);
                    }
                }
                res.Add(tollBuffer);
            }
        }

        /// <summary>
        /// 移动基站信息解析
        /// "0,0,2015-03-28 11:05:00,46001,FULL,22,255,{46001,7121,35521,22,-69,4}{{EDGE,7121,54842,11},{EDGE,7121,55303,14},{EDGE,7121,30101,10},{EDGE,7121,48381,21},{EDGE,7121,35522,10},{EDGE,0,65535,11},{EDGE,7121,59772,9}},{10,114.06388207,30.45467572,19.600000381469727,46.8,2015-03-28 11:04:52}"
        /// 37,0,2015-03-21 14:29:35,46000,FULL,28,-1,{46000,29071,32202,28,-57,4}{{},{},{},{},{},{}},{9,113.49892102181911,32.3118727421388,118.0,5.6295,2015-03-21 14:29:35}
        /// 38,0,2015-03-22 16:04:25,46001,FULL,16,1,{46001,21088,50102,16,-81,4}{{GPRS,21088,16131,16},{GPRS,0,65535,17},{GPRS,21088,50152,24},{GPRS,0,65535,17},{GPRS,0,65535,14},{GPRS,21088,38451,14}},{16,110.79304166,32.67936288,244.39999389648438,82.799995,2015-03-22 16:04:09}
        ///187,0,2015-03-22 16:16:51,,NO,4,255,{,-1,-1,4,-105,1}{{},{},{},{},{},{}},{8,110.86390305,32.66266531,302.70001220703125,81.0,2015-03-22 16:15:16}
        /// 3716,0,2015-03-29 15:39:41,46000,FULL,23,-1,{46000,29147,5033,23,-67,4}{},{8,108.60729438252747,30.196607024408877,1341.0,59.6727,2015-03-29 15:39:37}
        /// </summary>
        /// <param name="line">包含移动基站信息的字符串</param>
        private void ParseCellBase(string line, ref CellBaseSet cellBaseSet)
        {
            if (line.Contains("FULL"))
            {
                try
                {
                    //包含6组
                    if (line.Contains("}{{"))
                    {
                        line = line.Replace("{{", ",{");
                        var bufInfo = line.Split('{');
                        //解析坐标
                        //9,113.49892102181911,32.3118727421388,118.0,5.6295,2015-03-21 14:29:35}
                        //114.6945608,29.72459612,128.39999389648438,88.2
                        int N = bufInfo.Length;
                        if (bufInfo[N - 1].Length < 10)
                            return;
                        Coordinate position;
                        GetCellBaseCoor(bufInfo[N - 1], out position);

                        for (int i = 1; i < N - 2; i++)
                        {
                            //46000,29071,32202,28,-57,4}
                            if (bufInfo[i].Length > 10)
                            {

                                string lac, id;
                                ParseCellBaseId(bufInfo[i], out lac, out id);
                                if (lac != "0000")
                                {
                                    CellBase cellBase = new CellBase();
                                    cellBase.Id = id;
                                    cellBase.Lac = lac;
                                    cellBase.Type = 0;
                                    cellBase.Position = position;
                                    cellBaseSet.Add(cellBase);
                                }
                            }

                        }
                    }
                    else //只包含一组
                    {

                        line = line.Replace("}{}", ",}");
                        var bufInfo = line.Split('{');
                        //解析坐标
                        //8,108.60729438252747,30.196607024408877,1341.0,59.6727,2015-03-29 15:39:37}
                        if (bufInfo[2].Length < 10) return;
                        Coordinate position;
                        GetCellBaseCoor(bufInfo[2], out position);
                        //46000,29147,5033,23,-67,4}
                        if (bufInfo[1].Length > 10)
                        {
                            string lac, id;
                            ParseCellBaseId(bufInfo[1], out lac, out id);
                            if (id != "0000")
                            {
                                CellBase cellBase = new CellBase();
                                cellBase.Id = id;
                                cellBase.Lac = lac;
                                cellBase.Type = 0;
                                cellBase.Position = position;
                                cellBaseSet.Add(cellBase);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    string text = $"CellBaseReader.02: {ex.Message}--{line}";
                    Logger.WriteError(text);
                }
            }

        }

        /// <summary>
        /// 1. 解析移动基站信息
        /// 46000,29071,32202,28,-57,4}
        /// 2. 转成16进制
        /// </summary>
        private void ParseCellBaseId(string s, out string Lac, out string Id)
        {
            Lac = string.Empty;
            Id = string.Empty;
            try
            {
                var buf = s.Split(',');
                //cellBase.Lac = $"{buf[1]:X}";
                int lac = Convert.ToInt32(buf[1]);
                int id = Convert.ToInt32(buf[2]);
                Lac = $"{lac:X4}";
                Id = $"{lac:X4}{id:X4}";
            }
            catch (Exception ex)
            {
                string text = $"CellBaseReader.03: {ex.Message}--{s}";
                Logger.WriteError(text);
            }
        }

        /// <summary>
        /// 解析坐标
        /// 9,113.49892102181911,32.3118727421388,118.0,5.6295,2015-03-21 14:29:35}
        /// </summary>
        private void GetCellBaseCoor(string s, out Coordinate point)
        {
            point = new Coordinate();
            try
            {
                var buf = s.Split(',');
                int n = Convert.ToInt32(buf[0]);
                if (n > 4)
                {
                    point.Lon = Convert.ToDouble(buf[1]);
                    point.Lat = Convert.ToDouble(buf[2]);
                    point.Height = Convert.ToDouble(buf[3]);
                    point.Weight = 1;
                }

            }
            catch (Exception ex)
            {
                string text = $"CellBaseReader.01: {ex.Message}--{s}";
                Logger.WriteError(text);
            }

        }

        /// <summary>
        /// 收费站解析
        /// 08501,琴台
        /// </summary>
        /// <param name="line">包含收费站、服务区等信息的字符串</param>
        private TollStation ParseKeyPoint(string line)
        {
            line = line.Replace("~", "");
            TollStation pt = new TollStation();
            var buf = line.Split(',');
            if (buf.Length == 2)
            {
                pt.Code = Convert.ToInt32(buf[0]);
                pt.Name = $"{buf[1]}";
            }
            return pt;
        }

        List<string> ReadFileList(string dir, string file)
        {
            List<string> list = new List<string>();
            string path = $"{dir}/{file}";
            var reader = new StreamReader(path);
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                path = $"{dir}/{line}";
                list.Add(path);
            }
            reader.Close();
            return list;
        }


    }
}
