﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace DataBase
{
    /// <summary>
    /// 读取基础数据
    /// </summary>
    public class BasicDataReader
    {
        /// <summary>
        /// 道路片段列表
        /// </summary>
        public RoadBufferSet RoadSegments { get; set; }
        /// <summary>
        /// 收费站列表数据
        /// </summary>
        public TollStationSet FeeStations { get; set; }

        public BasicDataReader()
        {
            RoadSegments = new RoadBufferSet();
            FeeStations = new TollStationSet();
        }

        public List<string> ReadFileList(string dir, string file)
        {
            List<string> list=new List<string>();
            var reader=new StreamReader(file);
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string path = $"{dir}/{line}";
                list.Add(path);
            }
            reader.Close();
            return list;
        }

        public void Read(string file)
        {
            try
            {
                var reader = new StreamReader(file);
                RoadBuffer segment = new RoadBuffer();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();

                    //#2015-03-28 16:34:40,白河服务区
                    if (line.Contains("#"))
                    {
                        var point = ParseKeyPoint(line);
                        if (segment.StartPoint.Name == string.Empty)
                        {
                            segment.StartPoint = point;
                        }
                        else
                        {
                            segment.EndPoint = point;
                            //进行该片段数据的整理
                            segment.PostProcess();
                            RoadSegments.Add(segment);
                            FeeStations.Add(segment.StartPoint);
                            FeeStations.Add(segment.EndPoint);
                            //重置片段
                            segment = new RoadBuffer();
                            segment.StartPoint = point;

                        }
                    }
                    //"0,0,2015-03-28 11:05:00,46001,FULL,22,255,{46001,7121,35521,22,-69,4}{{EDGE,7121,54842,11},{EDGE,7121,55303,14},{EDGE,7121,30101,10},{EDGE,7121,48381,21},{EDGE,7121,35522,10},{EDGE,0,65535,11},{EDGE,7121,59772,9}},{10,114.06388207,30.45467572,19.600000381469727,46.8,2015-03-28 11:04:52}"
                    else if (line.Contains("{46001,") || line.Contains("{46000,"))
                    {
                        ParseCellBase(line, ref segment);
                    }
                }
                reader.Close();

            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

        }
        /// <summary>
        /// 路段起始点解析
        /// #2015-03-28 16:34:40,白河服务区
        /// #2015-03-21 13:02:21,09汉十高速,11006洛阳店
        /// </summary>
        /// <param name="line">包含收费站、服务区等信息的字符串</param>
        private TollStation ParseKeyPoint(string line)
        {
            line = line.Replace("~", "");
            TollStation pt = new TollStation();
            var buf = line.Split(',');
            if (buf.Length == 2)
            {
                pt.Name = buf[1];
            }
            else if (buf.Length == 3)
            {
                pt.Name = buf[2];
                pt.Road = buf[1];
            }
            return pt;
        }

        /// <summary>
        /// 移动基站信息解析
        /// "0,0,2015-03-28 11:05:00,46001,FULL,22,255,{46001,7121,35521,22,-69,4}{{EDGE,7121,54842,11},{EDGE,7121,55303,14},{EDGE,7121,30101,10},{EDGE,7121,48381,21},{EDGE,7121,35522,10},{EDGE,0,65535,11},{EDGE,7121,59772,9}},{10,114.06388207,30.45467572,19.600000381469727,46.8,2015-03-28 11:04:52}"
        /// 37,0,2015-03-21 14:29:35,46000,FULL,28,-1,{46000,29071,32202,28,-57,4}{{},{},{},{},{},{}},{9,113.49892102181911,32.3118727421388,118.0,5.6295,2015-03-21 14:29:35}
        /// 38,0,2015-03-22 16:04:25,46001,FULL,16,1,{46001,21088,50102,16,-81,4}{{GPRS,21088,16131,16},{GPRS,0,65535,17},{GPRS,21088,50152,24},{GPRS,0,65535,17},{GPRS,0,65535,14},{GPRS,21088,38451,14}},{16,110.79304166,32.67936288,244.39999389648438,82.799995,2015-03-22 16:04:09}
        ///187,0,2015-03-22 16:16:51,,NO,4,255,{,-1,-1,4,-105,1}{{},{},{},{},{},{}},{8,110.86390305,32.66266531,302.70001220703125,81.0,2015-03-22 16:15:16}
        /// 3716,0,2015-03-29 15:39:41,46000,FULL,23,-1,{46000,29147,5033,23,-67,4}{},{8,108.60729438252747,30.196607024408877,1341.0,59.6727,2015-03-29 15:39:37}
        /// </summary>
        /// <param name="line">包含移动基站信息的字符串</param>
        private void ParseCellBase(string line, ref RoadBuffer segment)
        {
            if (line.Contains("FULL"))
            {
                try
                {
                    //包含6组
                    if (line.Contains("}{{"))
                    {
                        line = line.Replace("{{", ",{");
                        var bufInfo = line.Split('{');
                        //解析坐标
                        //9,113.49892102181911,32.3118727421388,118.0,5.6295,2015-03-21 14:29:35}
                        //114.6945608,29.72459612,128.39999389648438,88.2
                        int N = bufInfo.Length;
                        if (bufInfo[N-1].Length < 10)
                            return;
                        Coordinate position;
                        GetCellBaseCoor(bufInfo[N-1], out position);

                        for (int i = 1; i < N-2; i++)
                        {
                            //46000,29071,32202,28,-57,4}
                            if (bufInfo[i].Length > 10)
                            {

                                string lac, id;
                                ParseCellBaseId(bufInfo[i], out lac, out id);
                                if (lac != "0000")
                                {
                                    CellBase cellBase = new CellBase();
                                    cellBase.Id = id;
                                    cellBase.Lac = lac;
                                    cellBase.Type = 0;
                                    cellBase.Position = position;
                                    segment.Add(cellBase);
                                }
                            }

                        }
                    }
                    else //只包含一组
                    {

                        line = line.Replace("}{}", ",}");
                        var bufInfo = line.Split('{');
                        //解析坐标
                        //8,108.60729438252747,30.196607024408877,1341.0,59.6727,2015-03-29 15:39:37}
                        if (bufInfo[2].Length < 10) return;
                        Coordinate position;
                        GetCellBaseCoor(bufInfo[2], out position);
                        //46000,29147,5033,23,-67,4}
                        if (bufInfo[1].Length > 10)
                        {
                            string lac, id;
                            ParseCellBaseId(bufInfo[1], out lac, out id);
                            if (id != "0000")
                            {
                                CellBase cellBase = new CellBase();
                                cellBase.Id = id;
                                cellBase.Lac = lac;
                                cellBase.Type = 0;
                                cellBase.Position = position;
                                segment.Add(cellBase);
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    // ignored
                }
            }

        }
        /// <summary>
        /// 1. 解析移动基站信息
        /// 46000,29071,32202,28,-57,4}
        /// 2. 转成16进制
        /// </summary>
        private void ParseCellBaseId(string s, out string Lac, out string Id)
        {
            Lac = string.Empty;
            Id = string.Empty;
            try
            {
                var buf = s.Split(',');
                //cellBase.Lac = $"{buf[1]:X}";
                int lac = Convert.ToInt32(buf[1]);
                int id = Convert.ToInt32(buf[2]);
                Lac = $"{lac:X4}";
                Id = $"{lac:X4}{id:X4}";
            }
            catch (Exception)
            {
                // ignored
            }
        }

        /// <summary>
        /// 解析坐标
        /// 9,113.49892102181911,32.3118727421388,118.0,5.6295,2015-03-21 14:29:35}
        /// </summary>
        private void GetCellBaseCoor(string s, out Coordinate point)
        {
            point = new Coordinate();
            try
            {
                var buf = s.Split(',');
                point.Lon = Convert.ToDouble(buf[1]);
                point.Lat = Convert.ToDouble(buf[2]);
                point.Height = Convert.ToDouble(buf[3]);
                point.Weight = 1;
            }
            catch (Exception)
            {
                // ignored
            }

        }
    }
}
