﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;

namespace DataBase
{
    /// <summary>
    /// 准备顶点数据集
    /// </summary>
    public class PrepareTollStationSet
    {
        /// <summary>
        /// 将边的数据集合转换为顶点的数据集合
        /// </summary>
        /// <param name="edgeSet">边（路段）集合</param>
        /// <returns>顶点（收费站）集合</returns>
        public static TollBufferSet CreateTollStationSet(RoadBufferSet edgeSet)
        {
            var res = new TollBufferSet();
            try
            {
                foreach (var edge in edgeSet.Data)
                {
                    PushTollStation(ref res, edge);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

            return res;
        }
        /// <summary>
        /// 将边内的移动基站根据距离划分到顶点（起点和终点的收费站）内；
        /// 划分依据：
        ///   （1）移动基站覆盖的经验距离(L_EXP)
        ///        如果起点和终点的距离(L_BE)<L_EXP;将其中所有基站重复归属到两个端点
        ///   （2）如果L_BE>L_EXP，总距离的0.6范围内归属自己
        /// </summary>
        /// <param name="res">顶点（收费站）集合</param>
        /// <param name="edge">路段</param>
        private static void PushTollStation(ref TollBufferSet res, RoadBuffer edge)
        {
            //如果起点站是高权点
            if(Rejector.HighWeightTollStation(edge.StartPoint.Code))
            {
                PushTollStation(ref res, edge, edge.StartPoint);
            }
            //如果终点站是高权点
            else if(Rejector.HighWeightTollStation(edge.EndPoint.Code))
            {
                PushTollStation(ref res, edge, edge.EndPoint);
            }
            //如果起点是0权点
            else if(Rejector.ZeroWeightTollStation(edge.StartPoint.Code))
            {
                PushTollStation(ref res, edge, edge.EndPoint);
            }
            //如果终点是0权点
            else if(Rejector.ZeroWeightTollStation(edge.EndPoint.Code ))
            {
                PushTollStation(ref res, edge, edge.StartPoint);
            }
            //两个收费站点之间的距离很短，小于一个移动站覆盖范围
            else if (edge.Length < Configure.MaxCoverDistance)
            {
                PushTollStation(ref res, edge, edge.StartPoint);
                PushTollStation(ref res, edge, edge.EndPoint);
            }
            //两个基站之间的距离较长
            else
            {
                double limit = edge.Length * 0.6;
                if (edge.StartPoint.Valid())
                {
                    var start = new TollBuffer { Id = edge.StartPoint };

                    foreach (var d in edge.CellBaseList.Data)
                    {
                        if (d.Valid())
                        {
                            double length = CoorTrans.GetLength(start.Id.Position, d.Position);
                            if (length < limit)
                                start.Add(d);
                        }
                    }
                    res.Add(start);
                }

                if (edge.EndPoint.Valid())
                {
                    var end = new TollBuffer { Id = edge.StartPoint };
                    foreach (var d in edge.CellBaseList.Data)
                    {
                        if (d.Valid())
                        {
                            double length = CoorTrans.GetLength(end.Id.Position, d.Position);
                            if (length < limit)
                                end.Add(d);

                        }
                    }
                    res.Add(end);
                }

            }
        }
        /// <summary>
        /// 将边中移动基站压入到顶点toll的缓冲区中
        /// </summary>
        /// <param name="res"></param>
        /// <param name="edge"></param>
        /// <param name="toll"></param>
        private static void PushTollStation(ref TollBufferSet res, RoadBuffer edge, TollStation toll)
        {

            if (toll.Valid())
            {
                var tollBuffer = new TollBuffer { Id = toll };
                foreach (var d in edge.CellBaseList.Data)
                {
                    if (d.Valid())
                    {
                        tollBuffer.Add(d);
                    }
                }
                res.Add(tollBuffer);
            }
        }

    }
}
