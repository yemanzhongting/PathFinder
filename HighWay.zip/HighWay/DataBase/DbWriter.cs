﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace DataBase
{
    /// <summary>
    /// 基础数据保存
    /// </summary>
    public class DbWriter
    {
        /// <summary>
        /// 保存道路片段列表
        /// </summary>
        public static void WriteRoad(RoadBufferSet roadSegement, string file)
        {
            var writer = new StreamWriter(file);
            foreach (var road in roadSegement.Data)
            {
                writer.WriteLine(road.ToString());
            }
            writer.Close();
        }
        /// <summary>
        /// 保存收费站列表数据
        /// </summary>
        public static void WriteStations(TollStationSet feeStation, string file)
        {
            var writer = new StreamWriter(file);
            foreach (var pt in feeStation.Data)
            {
                writer.WriteLine(pt.ToString());
            }
            writer.Close();
        }
        /// <summary>
        /// 保存通讯分区表
        /// </summary>
        /// <param name="regionSet">分区数据集</param>
        /// <param name="file">输出文件</param>
        public static void WriteRegion(RegionSet regionSet,string file)
        {
            var writer = new StreamWriter(file);
            foreach (var region in regionSet.Data)
            {
                writer.WriteLine(region.ToString());
            }
            writer.Close();
        }

        /// <summary>
        /// 保存通讯分区表
        /// </summary>
        /// <param name="gridSet">分区数据集</param>
        /// <param name="file">输出文件</param>
        public static void WriteGrid(GridSet gridSet, string file)
        {
            var writer = new StreamWriter(file);
            foreach (var grid in gridSet.Data)
            {
                writer.WriteLine(grid.ToString());
            }
            writer.Close();
        }
    }
}
