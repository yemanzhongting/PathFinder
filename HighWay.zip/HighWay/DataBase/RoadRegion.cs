﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Common;

namespace DataBase
{
    /// <summary>
    /// 读取道路片段数据，进行路网构建
    /// </summary>
    public class RoadRegion
    {
        /// <summary>
        /// 读入详细的道路片段数据集
        /// </summary>s
        /// <param name="file">文件名称</param>
        public static RoadBufferSet ReadEdgeSetDetail(string file)
        {
            RoadBufferSet res = new RoadBufferSet();
            try
            {
                var reader = new StreamReader(file);
                RoadBuffer edge = new RoadBuffer();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line.Contains("#"))
                    {
                        ParseHeader(line, ref edge, ref reader);
                    }
                    else if (line.Contains("END"))
                    {
                        res.Add(edge);
                        edge = new RoadBuffer();
                    }
                    else
                    {
                        ParseCellBase(line, ref edge);

                    }
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

            return res;
        }

        public static RegionSet CreateRegionSet(RoadBufferSet edgeSet)
        {
            RegionSet rs = new RegionSet();
            try
            {
                foreach (var edge in edgeSet.Data)
                {
                    rs.AddEdge(edge);
                }

            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }

            return rs;
        }

        /// <summary>
        /// 1BD1F29F,114.10338,30.39757,16.93,48
        /// </summary>
        private static void ParseCellBase(string line, ref RoadBuffer edge)
        {
            CellBase cb=new CellBase();
            cb.Parse(line);
            edge.CellBaseList.Add(cb);
        }

        /// <summary>
        /// 读入头文件部分
        ///#513军山-510武汉西,9923.42
        //513军山,114.10338,30.39757,16.93,48
        //510武汉西,114.04929,30.47383,15.61,174
        //1BD1,1BD4,
        /// </summary>
        private static void ParseHeader(string line, ref RoadBuffer edge, ref StreamReader reader)
        {
            try
            {
                //解析第1行
                line = line.Replace("#", "");
                var buf = line.Split(',');
                edge.Id = buf[0];
                edge.Length = Convert.ToDouble(buf[1]);
                //读入并解析第2行
                line = reader.ReadLine();
                TollStation start = new TollStation();
                start.Parse(line);
                edge.StartPoint = start;
                //读入并解析第3行
                line = reader.ReadLine();
                TollStation end = new TollStation();
                end.Parse(line);
                edge.EndPoint = end;
                //读入并解析第4行
                line = reader.ReadLine();
                buf = line.Split(',');
                foreach (var b in buf)
                {
                    if (b.Length > 2)
                        edge.RegionCodeList.Add(b);
                }

            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
        }
    }
}
