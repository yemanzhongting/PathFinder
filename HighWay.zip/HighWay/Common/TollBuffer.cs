﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 收费站及其该站周围的移动基站
    /// </summary>
    public class TollBuffer
    {
        /// <summary>
        /// 收费站及其相关信息
        /// </summary>
        public TollStation Id { get; set; }
        /// <summary>
        /// 收费站Id
        /// </summary>
        public int Code => Id.Code;

        /// <summary>
        /// 收费站缓冲区内的移动基站
        /// </summary>
        public CellBaseSet CellbaseData { get; set; }

        public TollBuffer()
        {
            Id = new TollStation();
            CellbaseData = new CellBaseSet();
        }

        /// <summary>
        /// 向数据集增加一个移动基站
        ///  1. 如果不存在，则直接增加
        ///  2. 如果已经存在，则更新坐标
        /// </summary>
        public void Add(CellBase cellbase)
        {
            if (cellbase.Id.Length == 8)  //长度为8才有效
            {
                if (!CellbaseData.Contains(cellbase))
                {
                    CellbaseData.Add(cellbase);
                }
                else
                {
                    int index = CellbaseData.IndexOf(cellbase);
                    CellbaseData[index].Update(cellbase);
                }
            }
            
        }
        /// <summary>
        /// 判断该移动基站数组中是否存在
        ///  </summary>
        /// <param name="cellbaseId">移动基站的8位十六进制编码</param>
        /// <returns>如果存在，则返回true，否则为false</returns>
        public bool Contains(string cellbaseId)
        {
            var v = new CellBase { Id = cellbaseId };
            return CellbaseData.Contains(v);
        }
        public static bool operator ==(TollBuffer left, TollBuffer right)
        {
            if (right != null && (left != null && left.Id == right.Id))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator !=(TollBuffer left, TollBuffer right)
        {
            return !(left == right);
        }
        protected bool Equals(TollBuffer other)
        {
            return string.Equals(Id, other.Id);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((TollBuffer)obj);
        }
        public override int GetHashCode()
        {
            return (Id != null ? Id.GetHashCode() : 0);
        }
        public override string ToString()
        {
            //string res = $"#{Id.Id},{Id.Road},{Id.Position.ToString()}";
            //foreach (var d in CellbaseData.Data)
            //{
            //    res += $"\n{d.ToString()}";
            //}
            string res = $"#{Id.Code},{Id.Name}";
            foreach (var d in CellbaseData.Data)
            {
                res += $"\n{d.Id}";
            }
            res += "\nEND";
            return res;
        }
        /// <summary>
        /// 更新收费站相关的信息
        /// </summary>
        public void Update(TollBuffer station)
        {
            Id.Position.Upate(station.Id.Position);
            foreach (var d in station.CellbaseData.Data)
            {
                CellbaseData.Add(d);
            }
        }
    }
}
