﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 道路数据库
    /// </summary>
    public  class RoadSet
    {

        public List<Road> Data { get; set; }

        public RoadSet()
        {
            Data = new List<Road>();
        }

        public bool Valid()
        {
            if (Data.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Contains(Road road)
        {
            return Data.Contains(road);
        }

        public int IndexOf(Road road)
        {
            return Data.IndexOf(road);
        }


        public Road this[int i]
        {
            set { Data[i] = value; }
            get { return Data[i]; }
        }

        /// <summary>
        /// 向数据集增加一个道路（收费站等）
        ///  1. 如果不存在，则直接增加
        ///  2. 如果已经存在，忽略
        /// </summary>
        public void Add(Road road)
        {
            if (!Data.Contains(road))
            {
                Data.Add(road);
            }
           
        }
    }
}
