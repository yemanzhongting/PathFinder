﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 高速公路片段信息
    /// 每个片段包含起点、终点、以及该路段所有的有效通讯基准信息
    /// 这里是无向边
    /// </summary>
    public class RoadBuffer
    {
        public string Id { get; set; }
        public TollStation StartPoint { get; set; }
        public TollStation EndPoint { get; set; }

        private double length;
        /// <summary>
        /// 长度
        /// </summary>
        public double Length
        {
            get
            {
                if (length <= 0)
                {
                    return CoorTrans.GetLength(StartPoint.Position, EndPoint.Position);
                }
                else
                {
                    return length;
                }
            }
            set { length = value; }
        }

        /// <summary>
        /// 区域代码列表,16进制格式
        /// </summary>
        public List<string> RegionCodeList { get; set; }
        /// <summary>
        /// 基站Id列表
        /// </summary>
        public CellBaseSet CellBaseList { get; set; }

        public RoadBuffer()
        {
            length = -1;
            Id = string.Empty;
            StartPoint = new TollStation();
            EndPoint = new TollStation();
            RegionCodeList = new List<string>();
            CellBaseList = new CellBaseSet();
        }

        public bool Valid()
        {
            if (CellBaseList.Valid())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 增加一个移动基站
        ///  1. 如果该移动基站不存在，则增加
        ///  2. 如果存在，则更新数据
        /// </summary>
        /// <param name="cellBase">移动基站</param>
        public void Add(CellBase cellBase)
        {
            CellBaseList.Add(cellBase);
            if (!RegionCodeList.Contains(cellBase.Lac))
            {
                RegionCodeList.Add(cellBase.Lac);
            }
        }

        /// <summary>
        /// 返回移动基站ID的映射坐标
        /// </summary>
        /// <param name="cellBaseId"></param>
        /// <returns></returns>
        public string FindCeilId(string cellBaseId)
        {
            string res = string.Empty;
            CellBase cb=new CellBase();
            cb.Id = cellBaseId;
            if (CellBaseList.Contains(cb))
            {
                int index = CellBaseList.IndexOf(cb);
                res = CellBaseList[index].ToString();
                res += Id + "," + res;
            }
            return res;
        }
        /// <summary>
        /// 所有信息阅读完毕，进行打包处理
        /// </summary>
        public void PostProcess()
        {
            if (Valid())
            {
                StartPoint.Position = CellBaseList[0].Position;
                EndPoint.Position = CellBaseList[CellBaseList.Count - 1].Position;
                Id = $"{StartPoint.Name}-{EndPoint.Name}";
            }
        }

        public static bool operator ==(RoadBuffer left, RoadBuffer right)
        {
            if (right != null && left != null
                && left.StartPoint == right.StartPoint
                && left.EndPoint == right.EndPoint)
            {
                return true;
            }
            else if (right != null && left != null
                && left.StartPoint == right.EndPoint
                && left.EndPoint == right.StartPoint)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator !=(RoadBuffer left, RoadBuffer right)
        {
            return !(left == right);
        }
        protected bool Equals(RoadBuffer other)
        {
            bool flag1 = Equals(StartPoint, other.StartPoint) && Equals(EndPoint, other.EndPoint);
            bool flag2 = Equals(StartPoint, other.EndPoint) && Equals(EndPoint, other.StartPoint);
            return flag1 || flag2;
        }
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((RoadBuffer)obj);
        }
        public override int GetHashCode()
        {
            unchecked
            {
                return ((StartPoint != null ? StartPoint.GetHashCode() : 0) * 397) ^ (EndPoint != null ? EndPoint.GetHashCode() : 0);
            }
        }
        /// <summary>
        /// 用一条道路片段更新
        /// </summary>
        public void Update(RoadBuffer segment)
        {
            //更新区域代码
            foreach (var rc in segment.RegionCodeList)
            {
                if (!RegionCodeList.Contains(rc))
                {
                    RegionCodeList.Add(rc);
                }
            }
            //更新移动基站信息
            for (int i = 0; i < segment.CellBaseList.Count; i++)
            {
                CellBaseList.Add(segment.CellBaseList[i]);
            }

        }

        public override string ToString()
        {
            string res = $"#{Id},{Length:F2}\n";
            res += $"{StartPoint.ToString()}\n{EndPoint.ToString()}\n";

            foreach (var r in RegionCodeList)
            {
                res += $"{r.ToString()},";
            }
            foreach (var c in CellBaseList.Data)
            {
                res += $"\n{c.ToString()}";
            }
            res += "\nEND";
            return res;
        }
    }
}
