﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Common
{
    /// <summary>
    /// 根据电信区域代码分区;
    /// 服务于快速索引
    /// </summary>
    public class Region
    {
        /// <summary>
        /// 区域Id，16进制格式
        /// </summary>
        public string Id { get; set; }

        public RoadBufferSet RoadSegments { get; set; }
        public Region()
        {
            Id = string.Empty;
            RoadSegments = new RoadBufferSet();
        }

        public void AddEdge(RoadBuffer edge)
        {
            RoadSegments.Add(edge);
        }
        /// <summary>
        /// 根据CeilId查询所对应的道路片段
        /// </summary>
        /// <param name="cellBaseId">移动通信基站Id</param>
        /// <returns></returns>
        public List<string> FindEdgeString(string cellBaseId)
        {
            var res = new List<string>();
            foreach (var d in RoadSegments.Data)
            {
                var line = d.FindCeilId(cellBaseId);
                if (line.Length > 10)
                {
                    res.Add(line);
                }
            }
            return res;
        }
        /// <summary>
        /// 根据CeilId查询所对应的道路片段
        /// </summary>
        /// <param name="cellBaseId">移动通信基站Id</param>
        /// <returns></returns>
        public List<RoadBuffer> FindEdge(string cellBaseId)
        {
            var res = new List<RoadBuffer>();
            foreach (var d in RoadSegments.Data)
            {
                var line = d.FindCeilId(cellBaseId);
                if (line.Length > 10)
                {
                    res.Add(d);
                }
            }
            return res;
        }
        public static bool operator ==(Region left, Region right)
        {
            if (right != null && (left != null && left.Id == right.Id))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator !=(Region left, Region right)
        {
            return !(left == right);
        }
        protected bool Equals(Region other)
        {
            return string.Equals(Id, other.Id);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Region)obj);
        }

        public override int GetHashCode()
        {
            return (Id != null ? Id.GetHashCode() : 0);
        }

        public override string ToString()
        {
            string res = $"#{Id}";
            foreach (var edge in RoadSegments.Data)
            {
                res += $"\n{edge.Id}";
                foreach (var cellbase in edge.CellBaseList.Data)
                {
                    res += $",{cellbase.Id}";
                }
            }
            res += "\nEND";
            return res;
        }
    }
}
