﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 根据电信区域代码分区;
    /// 服务于快速索引
    /// </summary>
    public class Grid
    {

        /// <summary>
        /// 分区Id，16进制格式
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 收费站列表
        /// </summary>
        public TollStationSet Tolls { get; set; }
        public Grid()
        {
            Id = string.Empty;
            Tolls = new TollStationSet();
        }
        ///// <summary>
        ///// 搜索包含移动基站Id的收费站
        ///// </summary>
        ///// <param name="cellbaseId">移动基站Id</param>
        ///// <returns>收费站列表</returns>
        //public VertexSet FindTollList(string cellbaseId)
        //{
        //    var res=new VertexSet();
        //    foreach (var d in Tolls.Data)
        //    {
        //        var cellbase = new CellBase {Id = cellbaseId};

        //        if (d.)
        //        {
        //            res.Add(d);
        //        }
        //    }
        //    return res;

        //}

        /// <summary>
        /// 增加一个收费站
        /// </summary>
        /// <param name="toll"></param>
        public void AddVertex(TollStation toll)
        {
            Tolls.Add(toll);
        }

        public override string ToString()
        {
            string res = $"#{Id}";
            foreach (var d in Tolls.Data)
            {
                // res += $"\n{d.Id},{d.Position.ToString()}";
                res += $"\n{d.Code},{d.Name}";
            }
            res += "\nEND";
            return res;
        }

        public static bool operator ==(Grid left, Grid right)
        {
            if (right != null && (left != null && left.Id == right.Id))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Grid left, Grid right)
        {
            return !(left == right);
        }
        protected bool Equals(Grid other)
        {
            return string.Equals(Id, other.Id);
        }
        public override int GetHashCode()
        {
            return (Id != null ? Id.GetHashCode() : 0);
        }
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Grid)obj);
        }
    }
}
