﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 路线
    /// 【例】
    ///麻安高速G4213W
    ///11019谷城,111.60877,32.30632,83.84,594
    ///……
    ///11037房县,110.30705,31.95556,412.86,819
    ///……
    ///12049蒋家堰,109.59646,32.32147,510.84,1014
    ///关垭子
    ///END
    /// </summary>
    public class Road
    {
        /// <summary>
        /// 高速路段名称
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 起点
        /// </summary>
        public TollStation Start { get; set; }
        /// <summary>
        /// 终点
        /// </summary>
        public TollStation End { get; set; }
        /// <summary>
        /// 直线距离
        /// </summary>
        public double Length { get; set; }
        /// <summary>
        /// 方位角：终点相对于起点之间的关系
        /// N：北向
        /// NE：东北向
        /// E：东
        /// SE：东南
        /// S：南
        /// SW：西南
        /// W：西
        /// NW：西北
        /// </summary>
        public string Azimuth { get; set; }

        /// <summary>
        /// 该高速路段所包含的收费站点列表
        /// </summary>
        public TollStationSet Data { get; set; }

        public Road()
        {
            Id = string.Empty;
            Data = new TollStationSet();

            Start=new TollStation();
            End =new TollStation();
            Length = 0;
            Azimuth = string.Empty;
        }
        /// <summary>
        /// 向数据集增加一个关键点（收费站等）
        ///  1. 如果不存在，则直接增加
        ///  2. 如果已经存在，则更新坐标
        /// </summary>
        public void Add(TollStation keyPoint)
        {
            try
            {
                if (!Data.Contains(keyPoint))
                {
                    Data.Add(keyPoint);
                }
                else
                {
                    int index = Data.IndexOf(keyPoint);
                    Data[index].Update(keyPoint);
                }

            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }

        }

        public void Parse(string line)
        {
            try
            {
                TollStation keyPoint = new TollStation();
                keyPoint.Parse(line);
                Add(keyPoint);
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
        }

        public override string ToString()
        {
            string res = $"{Id}: {Length:F2}: {Azimuth}\n";
            res += $"{Start.ToString()}\n";
            foreach (var d in Data.Data)
            {
                res += d.ToString() + "\n";
            }
            res += End.ToString();
            return res;
        }
    }
}
