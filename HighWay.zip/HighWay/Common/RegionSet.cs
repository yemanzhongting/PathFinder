﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 区域划分数据集
    /// </summary>
    public class RegionSet
    {
        public List<Region> Data { set; get; }
        public RegionSet()
        {
            Data = new List<Region>();
        }
        /// <summary>
        /// 增加一条边
        /// 1. 一条边跨越多个分区
        /// 2.一个分区中有多条边
        /// </summary>
        public void AddEdge(RoadBuffer edge)
        {
            foreach (var regionId in edge.RegionCodeList)
            {
                Region r = new Region();
                AddRegion(regionId, edge);
            }
        }
        /// <summary>
        /// 根据区域Id，判断在数据中是否存在该区域
        /// </summary>
        /// <param name="regionId">移动分区ID</param>
        /// <returns>如果存在，则为真</returns>
        public bool Contains(string regionId)
        {
            var region = new Region();
            region.Id = regionId;
            if(Data.Contains(region))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
               
        /// <summary>
        /// 1. 如果该区域已经存在，则将该边加入
        /// 2. 如果该区域不存在，则创建区域，然后放入边
        /// </summary>
        /// <param name="regionId"></param>
        /// <param name="edge"></param>
        private void AddRegion(string regionId, RoadBuffer edge)
        {
            try
            {
                var region = new Region();
                region.Id = regionId;
                if(Data.Contains(region))
                {
                    int index = Data.IndexOf(region);
                    Data[index].AddEdge(edge);
                }
                else
                {
                    region.AddEdge(edge);
                    Data.Add(region);
                }

            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
        }
        /// <summary>
        /// 根据移动基站Id快速找到路段，查找步骤分2个步骤
        /// 1. 根据区域编号找到所在区域
        /// 2. 根据区域找到路段
        /// </summary>
        /// <param name="cellId"></param>
        /// <returns></returns>
        public string FindEdgeString(string cellId)
        {
            string res = string.Empty;
            try
            {
                string regionId = cellId.Substring(0, 4);

                if(Contains(regionId))
                {
                    var r = new Region();
                    r.Id = regionId;

                    int index = Data.IndexOf(r);
                    var region = Data[index];
                    var buf = region.FindEdgeString(cellId);
                    foreach (var item in buf)
                    {
                        res += $"{ item};";
                    }                    
                }               
            }
            catch (Exception ex)
            {
                Logger.WriteError(cellId + ":" + ex.Message);
            }
            if(res.Length<5)
            {
                res = $"无法搜索相关路段, 基站Id为:{cellId}";
            }
            return res; 
        }
        /// <summary>
        /// 根据移动基站Id快速找到路段，查找步骤分2个步骤
        /// 1. 根据区域编号找到所在区域
        /// 2. 根据区域找到路段
        /// </summary>
        /// <param name="cellId"></param>
        /// <returns></returns>
        public RoadBufferSet FindEdge(string cellId)
        {
            var res =new RoadBufferSet(); 
            try
            {
                string regionId = cellId.Substring(0, 4);

                if (Contains(regionId))
                {
                    var r = new Region();
                    r.Id = regionId;

                    int index = Data.IndexOf(r);
                    var region = Data[index];
                    var buf = region.FindEdge(cellId);
                    foreach (var item in buf)
                    {
                        res.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteError(cellId + ":" + ex.Message);
            }
            //if (res.Count <1)
            //{
            //    res = $"无法搜索相关路段, 基站Id为:{cellId}";
            //}
            return res;
        }
    }
}
