﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 卡片数据
    /// </summary>
    public class Card
    {
        /// <summary>
        /// 卡片编号
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 入口收费站编码
        /// </summary>
        public int StartCode { get; set; }
        /// <summary>
        /// 入站时间
        /// </summary>
        public DateTime StartTime { get; set; }
        /// <summary>
        /// 出口收费站编码
        /// </summary>
        public int EndCode { get; set; }
        /// <summary>
        /// 出站时间
        /// </summary>
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 时间长度，以分钟为单位
        /// </summary>
        public double TimeLength { get; set; }

        /// <summary>
        /// 车牌号码
        /// </summary>
        public string CarNumber { get; set; }
        /// <summary>
        /// 基站数量
        /// </summary>
        public int TotalBaseStation { get; set; }

        public List<string> CellBaseList { get; set; }
        /// <summary>
        /// 如果时间与记录数目相符合，则为true，否则为false
        /// </summary>
        public bool Valid { get; set; }
        public Card()
        {
            Id = string.Empty;
            StartCode = -1;
            StartTime = new DateTime(2000, 1, 1);
            EndCode = -1;
            EndTime = new DateTime(2000, 1, 1);
            TimeLength = 0;
            Valid = true;
            CarNumber = string.Empty;
            TotalBaseStation = 0;
            CellBaseList = new List<string>();
        }
        /// <summary>
        /// 根据文件格式，进行数据解析
        /// #卡号,入口收费站编码,入站时间,出口收费站编码,出站时间,基站数量（十六进制）,基站列表
        ///2040006244,10563,2015-01-28 09:13:46.000,10560,2015-01-28 10:57:52.000,蓝鄂Q23H27,0A,71DA8590704F52BC704F84D071DD269871DD218F71DD848A71DD213F71D910C271DE25D2704D21A40000
        ///2040002131,510,2015-01-28 08:48:19.000,10536,2015-01-28 11:08:19.000,黄鄂AJA663,0F,70368EBE702BA30E702B886070AF9E2D70C8C81570F29CE270C6C8DE70F5C82070F5C8F270F6D7E870F6E82870C09C9B70C0D8B170C0D7FD705253B80000
        /// </summary>
        /// <param name="line">包含一张卡片的所有信息</param>
        public void Parse(string line)
        {
            try
            {
                var buf = line.Split(',');
                Id = buf[0];
                StartCode =Convert.ToInt32( buf[1]);
                StartTime = ParseTime(buf[2]);
                EndCode =Convert.ToInt32( buf[3]);
                EndTime = ParseTime(buf[4]);

                TimeSpan tv = EndTime - StartTime;
                TimeLength =tv.Days*24*60+ tv.Hours*60+ tv.Minutes;

                CarNumber = buf[5];
                TotalBaseStation = Convert.ToInt32(buf[6], 16);

                if (Math.Abs(TimeLength / 10 - TotalBaseStation) < 2)
                {
                    Valid = true;
                }
                else
                {
                    Valid = false;
                }

                for (int i = 0; i < TotalBaseStation; i++)
                {
                    var cellId = buf[7].Substring(i * 8, 8);
                    CellBaseList.Add(cellId);
                }
            }
            catch (Exception ex)
            {
                string text = $"{line} -----{ex.Message}";
                Logger.WriteError(text);
            }
        }
        /// <summary>
        /// 将字符串转为时间
        /// </summary>
        private DateTime ParseTime(string v)
        {
            var dt = Convert.ToDateTime(v);
            return dt;
        }
        /// <summary>
        /// 头文件字符串
        /// </summary>
        /// <returns></returns>
        public string HeaderString()
        {
            string res =
                $"#{Id},{StartCode},{StartTime.ToLongTimeString()},{EndCode},{EndTime.ToLongTimeString()},{TimeLength},{Valid}, {CarNumber},{TotalBaseStation}";
            return res;
        }
    }
}
