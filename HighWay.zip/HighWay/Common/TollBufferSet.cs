﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 收费站集合
    /// </summary>
    public class TollBufferSet
    {

        public List<TollBuffer> Data;

        public TollBufferSet()
        {
            Data = new List<TollBuffer>();
        }

        public int Count => Data.Count;

        public int IndexOf(TollStation vertex)
        {
            int i = -1;
            try
            {
                var toll = new TollBuffer { Id = vertex };
                i = Data.IndexOf(toll);

            }
            catch (Exception ex)
            {

                Logger.WriteError(ex.Message);
            }

            return i;
        }

        /// <summary>
        /// 增加收费站
        /// 1.如果该收费不站存在，则直接增加
        /// 2.如果收费存在，则更新相关数据
        /// </summary>
        /// <param name="station"></param>
        public void Add(TollBuffer station)
        {
            //if (Rejector.CheckTollStation(station.Code))
            if (!Rejector.ZeroWeightTollStation(station.Code))
            {
                if (!Data.Contains(station))
                {
                    Data.Add(station);
                }
                else
                {
                    int index = Data.IndexOf(station);
                    Data[index].Update(station);
                }
            }
           
        }
       

    }
}
