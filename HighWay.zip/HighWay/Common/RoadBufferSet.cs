﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 边的集合
    /// </summary>
    public class RoadBufferSet
    {
        public List<RoadBuffer> Data;

        public RoadBufferSet()
        {
          Data=new List<RoadBuffer>();  
        }

        public int Count => Data.Count;

        /// <summary>
        /// 增加道路片段
        /// 1.如果该道路片段不存在，则直接增加
        /// 2.如道路片段存在，则更新片段数据
        /// </summary>
        /// <param name="segment"></param>
        public void Add(RoadBuffer segment)
        {
            if (!Data.Contains(segment))
            {
                Data.Add(segment);
            }
            else
            {
                int index = Data.IndexOf(segment);
                Data[index].Update(segment);
            }
        }
        /// <summary>
        /// 1.根据移动基站ID查找匹配的路段Id
        /// 2.返回移动基站ID的映射坐标
        /// </summary>
        /// <param name="cellBaseId"></param>
        /// <returns></returns>
        public List<string> FindEdge(string cellBaseId)
        {
            List<string> res=new List<string>();
            foreach (var d in Data)
            {
                string ed= d.FindCeilId(cellBaseId);
                if (ed.Length > 0)
                {
                    res.Add(d.Id+","+ed);
                }
            }
            return res;
        }

        public TollStationSet ToVertexSet
        {
            get
            {
                var res=new TollStationSet();
                foreach (var d in Data)
                {
                    res.Add(d.StartPoint);
                    res.Add(d.EndPoint);
                }
                return res;
            }
        }
    }
}
