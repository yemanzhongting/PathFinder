﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 坐标
    /// </summary>
    public class Coordinate
    {
        /// <summary>
        /// 观测点数目
        /// </summary>
        public int Weight { get; set; }
        public double Lon { get; set; }

        public double Lat { get; set; }

        public double Height { get; set; }

        public Coordinate()
        {
            Weight = 0;
            Lon = 0;
            Lat = 0;
            Height = 0;
        }

        public bool Valid()
        {
            return Valid(Lon, Lat, Height, Weight);
        }

        bool Valid(double lon,double lat, double height, int weight)
        {
            if (lon < Configure.MinLon || lon > Configure.MaxLon)
            {
                return false;
            }
            if (lat < Configure.MinLat || lat > Configure.MaxLat)
            {
                return false;
            }
            if (height < Configure.MinHeight || height > Configure.MaxHeight)
            {
                return false;
            }
            if (weight < 1)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// 更新相关内容
        /// </summary>
        /// <param name="lon">经度</param>
        /// <param name="lat">纬度</param>
        /// <param name="height">高程</param>
        /// <param name="weight">计算位置所用的数据量</param>
        public void Upate(double lon, double lat, double height, int weight)
        {
            if (Valid(lon,lat,height,weight))
            {
                Lon = (Lon * Weight + lon * weight) / (weight + Weight);
                Lat = (Lat * Weight + lat * weight) / (weight + Weight);
                Height = (Height * Weight + height * weight) / (weight + Weight);
                Weight = Weight + weight;
            }
        }

        public void Upate(double lon, double lat, double height)
        {
            Upate(lon, lat, height, 1);
        }
        public void Upate(Coordinate point)
        {
            Upate(point.Lon,point.Lat,point.Height,point.Weight);
        }

        public override string ToString()
        {
            string line = $"{Lon:f5},{Lat:f5},{Height:f2},{Weight}";
            return line;
        }
    }
}
