﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 收费站、服务区、互动点等信息
    /// </summary>
    public class TollStation
    {
        public override int GetHashCode()
        {
            return (Code.GetHashCode());
        }

        //11006洛阳店
        public string Name { get; set; }
        //11006
        public int Code { get; set; }
        //09汉十高速
        public string Road { set; get; }

        //{8,113.43850985,31.4618675,90.19999694824219}
        public Coordinate Position { get; set; }

        public TollStation()
        {
            Name = string.Empty;
            Code = -1;
            Road = string.Empty;
            Position = new Coordinate();
        }

        /// <summary>
        /// 00513军山,114.10338,30.39757,16.93,48
        /// 00513军山,,114.11106,30.38836,22.95,562
        /// </summary>
        /// <param name="line">输入信息</param>
        public void Parse(string line)
        {
            try
            {
                var buf = line.Split(',');
                if (buf.Length == 5)
                {
                    //Name = buf[0];
                    //Code =Convert.ToInt32( buf[0].Substring(0, 5));
                    //Position.Lon = Convert.ToDouble(buf[1]);
                    //Position.Lat = Convert.ToDouble(buf[2]);
                    //Position.Height = Convert.ToDouble(buf[3]);
                    //Position.Weight = Convert.ToInt32(buf[4]);

                    Code = Convert.ToInt32(buf[0]);
                    Name = buf[1];
                    Position.Lon = Convert.ToDouble(buf[2]);
                    Position.Lat = Convert.ToDouble(buf[3]);
                    Position.Height = Convert.ToDouble(buf[4]);
                }
                else if(buf.Length>5)
                {
                    //Name = buf[0];
                    //Code = Convert.ToInt32(buf[0].Substring(0, 5));
                    //Position.Lon = Convert.ToDouble(buf[2]);
                    //Position.Lat = Convert.ToDouble(buf[3]);
                    //Position.Height = Convert.ToDouble(buf[4]);
                    //Position.Weight = Convert.ToInt32(buf[5]);
                  
                    Code = Convert.ToInt32(buf[0]);
                    Name = buf[1];
                    Position.Lon = Convert.ToDouble(buf[2]);
                    Position.Lat = Convert.ToDouble(buf[3]);
                    Position.Height = Convert.ToDouble(buf[4]);
                    //Position.Weight = Convert.ToInt32(buf[5]);
                }
                else if (buf.Length == 1)
                {
                    Name = buf[0];
                    Position.Lon = 0;
                    Position.Lat = 0;
                    Position.Height = 0;
                    Position.Weight = 0;
                }
               
            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
        }

        /// <summary>
        /// 是否为有效的站点
        /// </summary>
        public bool Valid()
        {
            if (Name.Length > 0 && Position.Weight > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Update(double lon, double lat, double height)
        {
            Position.Upate(lon, lat, height);
        }

        public void Update(TollStation cellBase)
        {
            Position.Upate(cellBase.Position);
        }
        public static bool operator ==(TollStation left, TollStation right)
        {
            if (right != null && (left != null && left.Code == right.Code))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(TollStation left, TollStation right)
        {
            return !(left == right);
        }
        protected bool Equals(TollStation other)
        {
            return string.Equals(Code, other.Code);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((TollStation)obj);
        }

        public override string ToString()
        {
            string res = $"{Code},{Name},{Position.ToString()}";
            return res;
        }
    }
}
