﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 基站信息
    /// </summary>
    public class CellBase
    {


        /// <summary>
        /// 基站小区号
        /// 十六进制
        /// </summary>
        public string Lac { get; set; }
        /// <summary>
        /// 基站号
        /// 十六进制
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 类型，0=实测结果；2学习结果
        /// </summary>
        public int Type { get; set; }

        public Coordinate Position { get; set; }
        public CellBase()
        {
            Lac = string.Empty;
            Id = string.Empty;
            Type = -1;
            Position = new Coordinate();
        }
        /// <summary>
        /// 是否为有效的站点
        /// </summary>
        public bool Valid()
        {
            if (Id.Length > 0 && Position.Weight > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 1BD1F29F,114.10338,30.39757,16.93,48
        /// </summary>
        public void Parse(string line)
        {
            try
            {
                var buf = line.Split(',');
                Id = buf[0];
                Lac = buf[0].Substring(0, 4);
                Position.Lon = Convert.ToDouble(buf[1]);
                Position.Lat = Convert.ToDouble(buf[2]);
                Position.Height = Convert.ToDouble(buf[3]);
                Position.Weight = Convert.ToInt32(buf[4]);

            }
            catch (Exception ex)
            {
                Logger.WriteError(ex.Message);
            }
        }

        public void Update(double lon, double lat, double height)
        {
            Position.Upate(lon, lat, height);
        }

        public void Update(CellBase cellBase)
        {
            Position.Upate(cellBase.Position);
        }
        public static bool operator ==(CellBase left, CellBase right)
        {
            if (right != null && (left != null && left.Id == right.Id))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(CellBase left, CellBase right)
        {
            return !(left == right);
        }

        protected bool Equals(CellBase other)
        {
            return string.Equals(Id, other.Id);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((CellBase)obj);
        }

        public override int GetHashCode()
        {
            return (Id != null ? Id.GetHashCode() : 0);
        }

        public override string ToString()
        {
            string res = Id + "," + Position.ToString();
            return res;
        }
    }
}
