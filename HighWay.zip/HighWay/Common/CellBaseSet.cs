﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 移动基站列表
    /// </summary>
    public class CellBaseSet
    {
        public List<CellBase> Data { get; set; }
        public CellBaseSet()
        {
            Data = new List<CellBase>();
        }

        public bool Valid()
        {
            if (Data.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public CellBase this[int i]
        {
            get { return Data[i]; }
            set { Data[i] = value; }
        }

        public int Count => Data.Count;

        /// <summary>
        /// 向数据集增加一个基站
        ///  1. 如果该基准不存在，则直接增加
        ///  2. 如果已经存在，则更新坐标
        /// </summary>
        /// <param name="cellBase"></param>
        public void Add(CellBase cellBase)
        {
            if (!Data.Contains(cellBase))
            {
                Data.Add(cellBase);
            }
            else
            {
                int index = Data.IndexOf(cellBase);
                Data[index].Update(cellBase);
            }
        }

        public void Add(CellBaseSet cellbaseSet)
        {
            foreach (var d in cellbaseSet.Data)
            {
                Add(d);
            }
        }

        internal bool Contains(CellBase cb)
        {
           
            return Data.Contains(cb);
        }

        internal int IndexOf(CellBase cellBase)
        {
            return Data.IndexOf(cellBase);
        }
    }
}
