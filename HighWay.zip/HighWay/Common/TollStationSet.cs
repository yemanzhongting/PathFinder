﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    /// <summary>
    /// 顶点集合
    /// </summary>
    public class TollStationSet
    {
        public List<TollStation> Data { get; set; }

        public TollStationSet()
        {
            Data=new List<TollStation>();
        }

        public bool Valid()
        {
            if (Data.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public int Count => Data.Count;

        public bool Contains(TollStation keyPoint)
        {
            return Data.Contains(keyPoint);
        }

        public int IndexOf(TollStation keyPoint)
        {
            return Data.IndexOf(keyPoint);
        }

        public int IndexOf(int code)
        {
            var toll = new TollStation { Code = code };
            return Data.IndexOf(toll);
        }


        public TollStation this[int i]
        {
            set { Data[i] = value; }
            get { return Data[i]; }
        }

        /// <summary>
        /// 向数据集增加一个关键点（收费站等）
        ///  1. 如果不存在，则直接增加
        ///  2. 如果已经存在，则更新坐标
        /// </summary>
        public void Add(TollStation keyPoint)
        {
            if (!Data.Contains(keyPoint))
            {
                Data.Add(keyPoint);
            }
            else
            {
                int index = Data.IndexOf(keyPoint);
                Data[index].Update(keyPoint);
            }
        }
        /// <summary>
        /// 根据收费站编码，找出对应的测站
        /// </summary>
        /// <param name="Code">收费站编码，如10101</param>
        /// <returns></returns>
        public TollStation Find(int Code)
        {
            //if (Code.Length < 5)
            //{
            //    int v = Convert.ToInt32(Code);
            //    Code = $"{v:00000}";
            //}

            var res=new TollStation();
            foreach (TollStation t in Data)
            {
                if (t.Code == Code)
                {
                    res = t;
                    break;
                }
            }
            return res;

        }

        public override string ToString()
        {
            string line = string.Empty;
            foreach (var d in Data)
            {
                line += $"{d.ToString()}\n";

            }
            return line;
        }
    }
}
