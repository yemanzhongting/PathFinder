﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Common
{
    public class Rejector
    {
        static List<int> HighWeightPt { get; set; }
        static List<int> ZeroWeightPt { get; set; }

        static Rejector()
        {
            ReadHeighWeightPt();
            ReadZeroWeightPt();

        }

        static void ReadHeighWeightPt()
        {
            HighWeightPt = new List<int>();
            try
            {
                string hwFile = $"{Configure.Root}/DataClean/高权点-V1.txt";
                var reader = new StreamReader(hwFile);
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    if (line.Length > 0)
                    {
                        var buf = line.Split(',');
                        int id = Convert.ToInt32(buf[0]);
                        HighWeightPt.Add(id);
                    }
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                string text = $"Rejector.01: {ex.Message}";
                Logger.WriteError(text);
            }
        }

        static void ReadZeroWeightPt()
        {
            ZeroWeightPt = new List<int>();
            try
            {
                string hwFile = $"{Configure.Root}/DataClean/零权点-V1.txt";
                var reader = new StreamReader(hwFile);
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    if (line.Length > 0)
                    {
                        var buf = line.Split(',');
                        int id = Convert.ToInt32(buf[0]);
                        ZeroWeightPt.Add(id);
                    }
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                string text = $"Rejector.02: {ex.Message}";
                Logger.WriteError(text);
            }
        }
        /// <summary>
        /// 是否剔除该点
        /// </summary>
        /// <param name="tollCode"></param>
        /// <returns></returns>
        public static bool CheckTollStation(int tollCode)
        {
            var list = new List<int>
            {
                //8601, 501,525,11536,             // 90072,  90046, 90015,
                //12050,11501,8301,2001,2017,90100,13032,
                //1501,10551,10565,10592,10503,10510,1001,
                //1027,13001,13013,11037,11546,10574,11000,
                //11030,11034,10401,10501,8101,8104,8201,
                //8601,8604,8501,8801,20111,20112,12001,
                //13020,10601,10545,8701,90109,10527,1036,
                //10579,8105,90029,62,10509,90041,515,10533,1513,
                //11524,11525,10544,1042,1041,1010,11008,
                90044,90040,10523,8706,13030,13022
            };

            if (list.Contains(tollCode))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool HighWeightTollStation(int tollcode)
        {
            if (HighWeightPt.Contains(tollcode))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ZeroWeightTollStation(int tollcode)
        {
            if (ZeroWeightPt.Contains(tollcode))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
