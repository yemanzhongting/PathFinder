﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Utility
    {
        public static double Median(List<double> list)
        {
            double res = 0;
            list.Sort();
            int n = list.Count;
            if (n%2 == 0)
            {
                int i = n/2;
                res = (list[i - 1] + list[i])/2;
            }
            else
            {
                int i = (n - 1)/2;
                res = list[i];
            }
            return res;
        }
    }
}
