﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace RoadNetwork
{
    public class RoadLink
    {
        /// <summary>
        /// 道路Id
        /// </summary>
        public string Road { get; set; }
        /// <summary>
        /// 已知站点
        /// </summary>
        List<Toll> TollList { get; set; }
        /// <summary>
        /// 连接列表
        /// </summary>
        public TollTollSet LinkList { get; set; }

        public RoadLink()
        {
            Road = string.Empty;
            TollList = new List<Toll>();
            LinkList = new TollTollSet();
        }


        public void FindRoad(string road, DataLib lib)
        {
            try
            {

                lib.ReadAll();
                Road = road;
                GetTollList(lib);

                var res = new TollTollSet();
                var history = new KeyPointSet();

                for (int i = 0; i < TollList.Count - 1; i++)
                {
                    history.Add(TollList[i].Station);

                    var data = GetLinks(TollList[i].Station,
                        TollList[i + 1].Station, lib, history);

                    res.Add(data);
                }
                LinkList = res;
            }
            catch (Exception ex)
            {
                string text = $"RoadLink.01: {ex.Message}--{road}";
                Logger.WriteError(text);
            }

        }

        /// <summary>
        /// 获取收费站列表
        /// </summary>
        void GetTollList(DataLib lib)
        {
            foreach (var t in lib.Tolldata)
            {
                if (t.Road == Road)
                {
                    TollList.Add(t);
                }
            }
        }
        /// <summary>
        /// 得到开始点为指定关键点的开始的所有路段
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        TollTollSet NextTolls(KeyPoint point, DataLib lib, KeyPointSet history)
        {
            var res = new TollTollSet();
            try
            {
                foreach (var tt in lib.T2Tdata.Data)
                {
                    int id = tt.Start.Code;
                    if (id == point.Code)
                    {
                        if (!history.Contains(tt.End))
                        {
                            //收费站
                            if (id < 90000)
                            {
                                //收费站列表中不包括该点
                                if (!lib.ContainToll(point))
                                {
                                    res.Add(tt);
                                }
                                //收费站列表中包括该点
                                else
                                {
                                    var toll = lib.GetToll(point);
                                    if (toll.Road == Road)
                                        res.Add(tt);
                                }
                            }
                            //互通点、虚拟点
                            else
                            {
                                res.Add(tt);
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                string text = $"RoadLink.02: {ex.Message}--{point.ToString()}";
                Logger.WriteError(text);
            }

            return res;
        }

        /// <summary>
        /// 根据起点与终点，搜索相关收费站邻接表
        /// </summary>
        /// <param name="start">开始点</param>
        /// <param name="end">结束点</param>
        /// <returns></returns>
        TollTollSet GetLinks(KeyPoint start, KeyPoint end, DataLib lib, KeyPointSet history)
        {
            var res = new TollTollSet();
            //获取所有的可能链接
            res = GetAllLinks(start, end, lib, history);
            //删除多余链接，并排序
            res = CleanLink(res);

            return res;
        }

        TollTollSet CleanLink(TollTollSet res)
        {
            try
            {
                int count = res.Data.Count;
                if (count > 0)
                {
                    int deepth = res.Data[count - 1].Id;
                    var links = new TollTollSet();

                    var data = res.Data[count - 1];

                    links.Add(data);
                    for (int i = deepth - 1; i >= 0; i--)
                    {
                        foreach (var item in res.Data)
                        {
                            if (item.End.Code == data.Start.Code && item.Id == i)
                            {
                                data = item;
                                links.Add(data);
                                break;
                            }
                        }
                    }
                    //重新排序
                    res = new TollTollSet();
                    for (int i = links.Data.Count - 1; i >= 0; i--)
                    {
                        res.Add(links.Data[i]);
                    }

                }
            }
            catch (Exception ex)
            {
                string text = $"RoadLink.03: {ex.Message}--{res.ToString()}";
                Logger.WriteError(text);
            }

            return res;
        }

        /// <summary>
        /// 获取所有的相关连接，只到有终止点出现
        /// </summary>
        TollTollSet GetAllLinks(KeyPoint start, KeyPoint end,
            DataLib lib, KeyPointSet history)
        {
            var res = new TollTollSet();
            try
            {
                int MaxDeepth = 8; //最大深度


                var next = NextTolls(start, lib, history);
                //将所有连接放入计算结果
                foreach (var item in next.Data)
                {
                    item.Id = 0;
                    res.Add(item);
                    history.Add(item.End);
                    if (item.End.Code == end.Code)
                    {
                        return res;
                    }
                }
                for (int i = 1; i < MaxDeepth; i++)
                {
                    //获取新一轮的搜索起点
                    var points = new KeyPointSet();
                    foreach (var item in next.Data)
                    {
                        points.Add(item.End);
                    }
                    //重置重置next
                    next = new TollTollSet();
                    foreach (var p in points.Data)
                    {
                        var nt = NextTolls(p, lib, history);

                        foreach (var tt in nt.Data)
                        {
                            tt.Id = i;
                            next.Add(tt);
                            res.Add(tt);
                            history.Add(tt.End);
                            if (tt.End.Code == end.Code)
                            {
                                return res;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string text = $"RoadLink.04: {ex.Message}--{start.ToString()}";
                Logger.WriteError(text);
            }

            return res;
        }

        public override string ToString()
        {
            string res = $"#{Road}";
            foreach (var item in LinkList.Data)
            {
                res += $"\n{item.ToString()}";
            }
            res += "\nEND";
            return res;
        }

        public string ToStringType2()
        {
            string res = $"#{Road}";
            int count = LinkList.Data.Count;
            for (int i = 0; i < count; i++)
            {
                var d = LinkList.Data[i];
                res += $"\n{d.Start.ToString()},{d.Distance:0.00}";
                if (i == count - 1)
                {
                    res += $"\n{d.End.ToString()},0.00";
                }
            }
            res += "\nEND";
            return res;
        }



        /// <summary>
        /// 解析
        /// #S58
        ///90019,荆宜汉宜交界,10544,伍家岗,10.326
        ///10544,伍家岗,10545,宜昌,11.731
        ///END
        /// </summary>
        /// <param name="line">站间距离表</param>
        public void Parse(string line)
        {
            try
            {
                var tt = new TollToll();
                if (line.Length < 1)
                    return;
                if (line.Contains("#"))
                {
                    Road = line.Replace("#", "");
                }
                else if (line.Contains("END"))
                {
                    //本路段结束
                }
                else
                {
                    var buf = line.Split(',');
                    tt.Id = 0;
                    tt.Start.Code = Convert.ToInt32(buf[0]);
                    tt.Start.Name = buf[1];
                    tt.End.Code = Convert.ToInt32(buf[2]);
                    tt.End.Name = buf[3];
                    tt.Distance = Convert.ToDouble(buf[4]);
                    LinkList.Add(tt);
                }
            }
            catch (Exception ex)
            {
                string text = $"RoadLink.cs: {ex.Message}--{line}";
                Logger.WriteError(text);
            }

        }
    }
}
