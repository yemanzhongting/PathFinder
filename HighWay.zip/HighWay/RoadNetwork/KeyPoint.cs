﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace RoadNetwork
{
    /// <summary>
    /// 关键点
    ///90001,孝南枢纽
    ///90002,汉孝交界
    /// </summary>
    public class KeyPoint
    {
        public int Code { get; set; }
        public string Name { get; set; }

        public int Weight { get; set; }
        public KeyPoint()
        {
            Code = -1;
            Name = string.Empty;
            Weight = 0;
        }
        /// <summary>
        /// 解析
        /// 例：90001,孝南枢纽
        /// </summary>
        public void Parse(string line)
        {
            try
            {
                var buf = line.Split(',');
                Code = Convert.ToInt32(buf[0]);
                Name = buf[1];

            }
            catch (Exception ex)
            {
                string text = $"KeyPoint.cs: {ex.Message}--{line}";
                Logger.WriteError(text);
            }
        }

        public static bool operator ==(KeyPoint left, KeyPoint right)
        {
            if (right != null && (left != null && left.Code == right.Code))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(KeyPoint left, KeyPoint right)
        {
            return !(left.Code == right.Code);
        }
        protected bool Equals(KeyPoint other)
        {
            return string.Equals(Code, other.Code);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((KeyPoint)obj);
        }

        public override int GetHashCode()
        {
            return (Code.GetHashCode());
        }

        public override string ToString()
        {
            string res = Code + "," + Name;
            return res;
        }

        public string ToWeightString()
        {
            string res = $"{Code},{Name},{Weight}";
            return res;
        }
    }
}
