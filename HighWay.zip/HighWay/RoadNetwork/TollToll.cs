﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;

namespace RoadNetwork
{
    /// <summary>
    /// 站间距离表
    ///11,90014,陵园交点,8104,陵园,0
    ///33,10401,黄梅南,10402,分路,0.532
    ///34,10402,分路,10401,黄梅南,0.532
    ///35,90022,金口枢纽,90115,金水枢纽,0.533
    /// </summary>
    public class TollToll
    {
        public int Id { get; set; }
        public KeyPoint Start { get; set; }

        public KeyPoint End { get; set; }

        public double Distance { get; set; }

        public TollToll()
        {
            Id = -1;
            Start = new KeyPoint();
            End = new KeyPoint();
            Distance = 0.0;

        }
        /// <summary>
        /// 解析
        /// 35,90022,金口枢纽,90115,金水枢纽,0.533
        /// </summary>
        /// <param name="line">站间距离表</param>
        public void Parse(string line)
        {
            try
            {
                var buf = line.Split(',');
                Id = Convert.ToInt32(buf[0]);
                Start.Code = Convert.ToInt32(buf[1]);
                Start.Name = buf[2];
                End.Code = Convert.ToInt32(buf[3]);
                End.Name = buf[4];
                Distance = Convert.ToDouble(buf[5]);
            }
            catch (Exception ex)
            {
                string text = $"TollToll.cs: {ex.Message}--{line}";
                Logger.WriteError(text);
            }

        }
        public static bool operator ==(TollToll left, TollToll right)
        {
            if (right != null && left != null)
            {
                if ((left.Start.Code == right.Start.Code) 
                    && (left.End.Code == right.End.Code))
                    return true;
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(TollToll left, TollToll right)
        {
            return ((left.Start.Code != right.Start.Code) 
                || (left.End.Code != right.End.Code));
        }
        protected bool Equals(TollToll other)
        {

            return string.Equals(Start.Code, other.Start.Code) && string.Equals(End.Code, other.End.Code);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((TollToll)obj);
        }

        public override int GetHashCode()
        {
            return (Id != null ? Start.GetHashCode() + End.GetHashCode() : 0);
        }

        public override string ToString()
        {
            string res = $"{Start.ToString()},{End.ToString()},{Distance}";
            return res;
        }

    }
}
