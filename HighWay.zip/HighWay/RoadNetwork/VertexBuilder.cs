﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadNetwork
{
    /// <summary>
    /// 构建路网的顶点
    /// </summary>
    public class VertexBuilder
    {
        public List<RoadLink> Data;

        public VertexBuilder()
        {
            Data = new List<RoadLink>();
        }

        public VertexBuilder(List<RoadLink> data)
        {
            Data = data;
        }
        /// <summary>
        /// 计算关键点
        /// </summary>
        public KeyPointSet FindKeyPoints()
        {
            var res = new KeyPointSet();

            foreach (var data in Data)
            {
                KeyPointSet ptSet = FindKeyPoints(data);
                res.AddWithWeight(ptSet);
            }
            return res;
        }
        private KeyPointSet FindKeyPoints(RoadLink data)
        {
            var res=new KeyPointSet();
            int count = data.LinkList.Data.Count;
            for (int i = 0; i < count; i++)
            {
                var d = data.LinkList.Data[i];
                if (i == 0)
                {
                    res.AddWithWeight(d.Start,1);
                }
                else if(i==count-1)
                {
                    res.AddWithWeight(d.End,2);
                }
                res.AddWithWeight(d.Start,1);
            }
            return res;
        }
    }
}
