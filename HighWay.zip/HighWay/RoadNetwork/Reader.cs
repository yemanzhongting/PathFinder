﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace RoadNetwork
{
    public class Reader
    {
        /// <summary>
        /// 读取站间距离表
        /// </summary>
        public static TollTollSet ReadTollToll(string filename)
        {
            var res = new TollTollSet();
            try
            {
                var reader = new StreamReader(filename);
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line.Length > 0)
                    {
                        var toll = new TollToll();
                        toll.Parse(line);
                        res.Add(toll);
                    }

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                string text = $"Reader.01: {ex.Message}--{filename}";
                Logger.WriteError(text);
            }
            return res;
        }
        /// <summary>
        /// 读取收费站-道路
        /// </summary>
        public static List<Toll> ReadTollRoad(string filename)
        {
            var res = new List<Toll>();
            try
            {
                var reader = new StreamReader(filename);
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line.Length > 0)
                    {
                        var toll = new Toll();
                        toll.Parse(line);
                        res.Add(toll);
                    }

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                string text = $"Reader.02: {ex.Message}--{filename}";
                Logger.WriteError(text);
            }
            return res;
        }
        /// <summary>
        /// 读取收费站-道路
        /// </summary>
        public static KeyPointSet ReadKeyPoint(string filename)
        {
            var res = new KeyPointSet();
            try
            {
                var reader = new StreamReader(filename);
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line.Length > 0)
                    {
                        var point = new KeyPoint();
                        point.Parse(line);
                        res.Add(point);
                    }

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                string text = $"Reader.03: {ex.Message}--{filename}";
                Logger.WriteError(text);
            }
            return res;
        }

        /// <summary>
        /// 读取路网文件
        /// </summary>
        public static List<RoadLink> ReadTRoadNetwork(string filename)
        {
            var res = new List<RoadLink>();
            try
            {
                var reader = new StreamReader(filename);
                var road = new RoadLink();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line.Contains("END"))
                    {
                        res.Add(road);
                        road = new RoadLink();
                    }
                    else
                    {
                        road.Parse(line);
                    }

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                string text = $"Reader.04: {ex.Message}--{filename}";
                Logger.WriteError(text);
            }
            return res;
        }
    }
}
