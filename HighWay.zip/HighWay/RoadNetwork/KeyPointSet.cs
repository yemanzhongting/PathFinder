﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadNetwork
{
    public class KeyPointSet
    {
        public List<KeyPoint> Data;
        public KeyPointSet()
        {
            Data = new List<KeyPoint>();
        }

        /// <summary>
        /// 增加一条记录，如果数据已经存在，则跳过
        /// </summary>
        /// <param name="point"></param>
        public void Add(KeyPoint point)
        {
            if (!Data.Contains(point))
            {
                Data.Add(point);
            }
        }
      
        public void Add(KeyPointSet pointSet)
        {
            foreach (var item in pointSet.Data)
            {
                Data.Add(item);
            }
        }

        /// <summary>
        /// 加入并赋予一定的权值
        /// </summary>
        public void AddWithWeight(KeyPoint point, int weight)
        {
            if (!Data.Contains(point))
            {
                point.Weight = weight;
                Data.Add(point);
            }
            else
            {
                int index = Data.IndexOf(point);
                Data[index].Weight += weight;
            }
        }

        /// <summary>
        /// 加入并赋予一定的权值
        /// </summary>
        public void AddWithWeight(KeyPointSet pointSet)
        {
            foreach (var pt in pointSet.Data)
            {
                AddWithWeight(pt,pt.Weight);
            }
        }
        /// <summary>
        ///是否包含关键点
        /// 在数据Keydata
        /// </summary>
        /// <returns></returns>
        public bool Contains(KeyPoint point)
        {
            return Data.Contains(point);
        }
    }
}
