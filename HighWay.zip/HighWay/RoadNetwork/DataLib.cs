﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace RoadNetwork
{
    public class DataLib
    {
        public KeyPointSet Keydata;
        public TollTollSet T2Tdata;
        public List<Toll> Tolldata;

        public DataLib()
        {
            Keydata = new KeyPointSet();
            T2Tdata = new TollTollSet();
            Tolldata = new List<Toll>();
        }

        public void ReadAll()
        {
            string kpFIle = @"D:\Data\Highway\DataClean\3互通ID对应表.csv";
            Keydata = Reader.ReadKeyPoint(kpFIle);

            string ttFile = @"D:\Data\Highway\DataClean\1站间距离表.csv";
            T2Tdata = Reader.ReadTollToll(ttFile);

            string trFile = @"D:\Data\Highway\DataClean\2高速公路-收费站.csv";
            Tolldata = Reader.ReadTollRoad(trFile);
        }

        /// <summary>
        /// 是否包含收费站
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        public bool ContainToll(KeyPoint point)
        {
            var toll = new Toll {Station = point};
            return Tolldata.Contains(toll);
        }
        /// <summary>
        /// 获取收费站
        /// </summary>
        /// <param name="point"></param>
        /// <returns></returns>
        public Toll GetToll(KeyPoint point)
        {
            var toll = new Toll { Station = point };
            if (Tolldata.Contains(toll))
            {
                int index = Tolldata.IndexOf(toll);
                toll = Tolldata[index];
            }
            return toll;
        }
    }
}
