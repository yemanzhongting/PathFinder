﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace RoadNetwork
{
    /// <summary>
    /// 高速公路-收费站
    /// 襄州北,1001,G55,G55
    /// 黄集,1002,G55,G55
    /// </summary>
    public class Toll
    {
        /// <summary>
        /// 收费站
        /// </summary>
        public KeyPoint Station;
        /// <summary>
        /// 道路Id
        /// </summary>
        public string Road { get; set; }
      
        public Toll()
        {
            Station = new KeyPoint();
            Road = string.Empty;
        }
        /// <summary>
        /// 解析
        /// 襄州北,1001,G55,G55
        /// </summary>
        public void Parse(string line)
        {
            try
            {
                var buf = line.Split(',');
                Station.Code = Convert.ToInt32(buf[1]);
                Station.Name = buf[0];
                Road = buf[2];
            }
            catch (Exception ex)
            {
                string text = $"Toll.cs: {ex.Message}--{line}";
                Logger.WriteError(text);
            }
        }

        public static bool operator ==(Toll left, Toll right)
        {
            if (right != null && (left != null && left.Station.Code == right.Station.Code))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Toll left, Toll right)
        {
            return !(left.Station.Code == right.Station.Code);
        }
        protected bool Equals(Toll other)
        {
            return string.Equals(Station, other.Station);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Toll)obj);
        }

        public override int GetHashCode()
        {
            return (Station.Code != null ? Station.Code.GetHashCode() : 0);
        }

        public override string ToString()
        {
            string res = Station.ToString() + "," + Road;
            return res;
        }


    }
}
