﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace RoadNetwork
{
    public class Writer
    {

        public static void WriteRoadNetwork(string file)
        {
            string[] roads = new string[] {
                "G4","G42","G4213","G4213M","G42S", "G45","G4E","G4W2",  //"G4201",
                "G50","G5012","G50E","G50W1", "G55","G56","G59",
                 "G6911","G70" ,"G7011","G70E" ,"G70E1" ,
                  "S1","S11","S13","S15","S17","S19",
                  "S29","S3","S31","S33",
                  "S40","S43", "S53","S63","S68",
                "S7","S74", "S78",
                 "S8", "S88", "S89"
            };
            DataLib lib = new DataLib();
            lib.ReadAll();
            RoadLink rl = new RoadLink();

            var writer = new StreamWriter(file);
            for (int i = 0; i < roads.Length; i++)
            {
                rl.FindRoad(roads[i], lib);
                writer.WriteLine(rl.ToString());
            }
            writer.Close();
        }

        public static void WriteKeyPoint(KeyPointSet ptSet, string file)
        {
            var writer=new StreamWriter(file);
            foreach (var pt in ptSet.Data)
            {
               if(pt.Weight>1)
                    writer.WriteLine(pt.ToWeightString()); 
            }
            writer.Close();
        }

        public static void WriteEdge(List<RoadLink> edges, string file)
        {
            var writer=new StreamWriter(file);
            foreach (var edge in edges)
            {
                writer.WriteLine(edge.ToString());
            }
            writer.Close();
        }
        public static void WriteEdge2(List<RoadLink> edges, string file)
        {
            var writer = new StreamWriter(file);
            foreach (var edge in edges)
            {
                writer.WriteLine(edge.ToStringType2());
            }
            writer.Close();
        }
    }
}
