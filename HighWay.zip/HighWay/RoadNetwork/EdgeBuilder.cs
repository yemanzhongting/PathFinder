﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadNetwork
{
    public class EdgeBuilder
    {
        public List<RoadLink> RoadData;
        public KeyPointSet PointData;

        public EdgeBuilder()
        {
            RoadData = new List<RoadLink>();
            PointData = new KeyPointSet();
        }

        public EdgeBuilder(List<RoadLink> roadData, KeyPointSet pointData)
        {
            RoadData = roadData;
            PointData = pointData;
        }

        public List<RoadLink> FindEdges()
        {
            var res = new List<RoadLink>();
            foreach (var road in RoadData)
            {
                List<RoadLink> edges = FindEdges(road);
                foreach (var edge in edges)
                {
                    res.Add(edge);
                }
            }
            return res;
        }
        /// <summary>
        /// 根据关键点，将一条道路打断为多条道路
        /// </summary>
        /// <param name="road"></param>
        /// <returns></returns>
        private List<RoadLink> FindEdges(RoadLink road)
        {
            var res = new List<RoadLink>();
            var link = new RoadLink();
            double dis = 0;
            string title = string.Empty;
            foreach (var item in road.LinkList.Data)
            {
                //路段开始
                if (PointData.Contains(item.Start))
                {
                    title = $"{item.Start.Code}";
                    dis = item.Distance;
                    link = new RoadLink();
                    link.LinkList.Add(item);
                }
                //路段结束
                if (PointData.Contains(item.End))
                {
                    link.LinkList.Add(item);
                    dis += item.Distance;
                    title += $",{item.End.Code},{dis},{road.Road}";
                    link.Road = title;
                    res.Add(link);
                }
                else if((!PointData.Contains(item.End))||(! PointData.Contains(item.Start)))
                {
                    link.LinkList.Add(item);
                    dis += item.Distance;
                }
            }
            return res;
        }
    }
}
