﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadNetwork
{
    /// <summary>
    ///  站间距离的集合
    /// </summary>
    public class TollTollSet
    {
        public List<TollToll> Data;

        public TollTollSet()
        {
            Data = new List<TollToll>();
        }
        /// <summary>
        /// 增加一条记录，如果数据已经存在，则跳过
        /// </summary>
        /// <param name="tollToll"></param>
        public void Add(TollToll tollToll)
        {
            if (!Data.Contains(tollToll))
            {
                Data.Add(tollToll);
            }
        }

        public void Add(TollTollSet ttSet)
        {
            foreach (var item in ttSet.Data)
            {
                Data.Add(item);
            }
        }
    }
}
